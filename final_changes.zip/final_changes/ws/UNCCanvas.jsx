import React, { Component } from "react";
import listReactFiles from 'list-react-files'
import { getRectPointX, getRectPointY } from "./CanvasUtils.js";
import { useState } from 'react'
import * as fs from "fs";
import {
  Stage,
  Polyline,
  Shape,
  Layer,
  Rect,
  Ellipse,
  Text,
  Circle,
  Line,
  Group,
  Arc,
  Image
} from "react-konva";
import { Navbar, Nav, NavItem, NavDropdown, MenuItem, Form, FormControl, Button, Container } from 'react-bootstrap';
import { getPloyPoints } from "./JSONUtil.js";
import UNCRectangle from "./UNCRectangle";
import preFunctions from "./preFunctions";
import UNCEllipse from "./UNCEllipse";
import UNCPipe from "./UNCPipe";
import UNCLine from "./UNCLine";
import UNCPolygon from "./UNCPolygon";
import UNCLabel from "./UNCLabel";
import UNCImage from "./UNCImages";

import { getStateObject, ShapeObjects } from "./JSONUtil";
import axios from 'axios';
import XMLData from './templates/xmlFiles/template_4.pagex';
import UNCDynamicText from "./UNCDynamicText.jsx";

import UNCText from "./UNCText.jsx";

import { isDOMComponentElement } from "react-dom/cjs/react-dom-test-utils.production.min";
import { androidToRgba, hextoRGBA, lineStyle,addParam ,emptyParamList} from './Utils';


class UNCCanvas extends Component {

  constructor(props) {
    super(props);
    this.state = {
      shapes: [],
      lables: [],
      loading: false,
      currentXml: "",
      xmlsList: [],
      windowheight: null,
      windowwidth: null,
      windowColor: "#004C99"
    };
    this.myRef = React.createRef();
    this.App = React.createRef();
  }

  componentDidMount() {
    const image = new window.Image();
    image.src = "assets/ecs.png";
    //image.src = "<E: /><Lx_Shared />rajesh/testsymbols//RED.png";
    image.onload = () => {
      this.setState({
        image: image
      });
    };
    //Default Index Xml- HomePage----
   // this.handleSubmit("ATestMobile1");
    this.handleSubmit("Home_Page");
    //Importing Xmls-------
    //this.importingXmls()
     //Importing Images-------
    this.importImages()
    this.GetMimicList()
  }

  importImages(){
    function importAll(r) {
      return r.keys().map(r);
    }
    //C:/ECWEBSERVERE/Images/
    var images = importAll(require.context('C:/ECWEBSERVER/Images/'));
    // //////console.log(images)
    this.setState({
      imagesList: images
    }, () => {
      //console.log(this.state.imagesList)
    })
  }

  //Dynamic Importing of Xmls------------------------
  // importingXmls() {
  //   function importAll(r) {
  //     return r.keys().map(r);
  //   }
  //   var xmls = importAll(require.context('C:/ECWEBSERVER/Xml/', false, /\.(pagex)$/));
  //   console.log(xmls)
    
  // }
  GetMimicList(){
    var url = process.env.REACT_APP_NODE_MIMIC_LIST_API_URL;
    var mimicEndpoint = url;
    var mimic_list = [];
   axios.get(mimicEndpoint, {
    //await axios.get("D:/Xml/AMOVSTATUS.pagex", {
    //wait axios.get("file://192.168.1.25/ecwebserver/Xml/AMOVSTATUS.pagex", {

    "Content-Type": "application/xml; charset=utf-8"
  }).then((response) => {
    console.log(response.data)
    mimic_list = response.data;
    this.setState({
      xmlsList: mimic_list
    }, () => {
      //   //////console.log(this.state.xmlsList)
    })
    //console.log(" ");
  }).catch(error => {
    console.log(error.response)
  });
  }


  //This Loads  User Selected Xml 
  async handleSubmit(event) {
    //console.log(event)
    this.setState({
      loading: true,
      currentXml: event,
      shapes:[]
    })
    ////////console.log(event)
    var parser = require('fast-xml-parser');
    var he = require('he');
    var options = {
      attributeNamePrefix: "",
      //attrNodeName: false,
      //textNodeName : "#text",
      ignoreAttributes: false,
      ignoreNameSpace: false,
      // attributeNamePrefix : "",
      // attrNodeName: "attr", //default is 'false'
      // textNodeName : "",
      // ignoreAttributes : true,
      // ignoreNameSpace : true,
      // allowBooleanAttributes : false,
      // parseNodeValue : true,
      // parseAttributeValue : false,
      // trimValues: true,
      cdataTagName: "__cdata", //default is 'false'
      cdataPositionChar: "\c",
      // parseTrueNumberOnly: false,
      // arrayMode: false, //"strict"
      // attrValueProcessor: (val, attrName) => he.decode(val, {isAttributeValue: true}),//default is a=>a
      // tagValueProcessor : (val, tagName) => he.decode(val), //default is a=>a
      // stopNodes: ["parse-me-as-string"]
    };

    ////console.log('./Xml/' + event + '.pagex')
    try {
      //alert(" opening "+event)
      var value = require('C:/ECWEBSERVER/Xml/' + event + '.pagex');
    } catch {

    }
    //alert("rajkumar")
    //alert(value.default)
     //console.log("for testing",value)
     //console.log("for testing gfjfdguuighdugfhui",value.default)
    var data = [];

    // function importAll2 (r) {
    //   return r.keys().map(r);
    // }
    // //var xmls2 = importAll2(require.context('C:/ECWEBSERVER/Xml/', false, /\.(pagex)$/));
    //this.importingXmls();

    //fs = require('fs');
    // Use fs.readFile() method to read the file

    //  fs.readFile('file://192.168.1.25/ecwebserver/Xml/AMOVSTATUS.pagex', (err, data) => { 
    //    console.log(data) })
    //"/static/media/Home_Page.1d21df34.pagex"
    var url = process.env.REACT_APP_NODE_MIMIC_API_URL;
    var mimicname = event;
    var mimicEndpoint = url + "mimic_name=" + mimicname;
    await axios.get(mimicEndpoint, {
    //await axios.get("D:/Xml/AMOVSTATUS.pagex", {
    //wait axios.get("file://192.168.1.25/ecwebserver/Xml/AMOVSTATUS.pagex", {
    
      "Content-Type": "application/xml; charset=utf-8"
    }).then((response) => {
      // //////console.log(response)
      data = response.data;
     
      console.log("abc ");
    }).catch(error => {
      console.log(error.response)
    });


    // Page Convertion---------------------------------------------------------------------
    var tObj = parser.getTraversalObj(data, options);
    var jsonObj = parser.convertToJson(tObj, options);
    //////console.log("jsonPage--------------------------------------------------------------")
    ////console.log(jsonObj)

    // this.setState({
    //   ProjectId: jsonObj.hmipage?.id
    // })

    var v = hextoRGBA(jsonObj.hmipage.color);
    ////////console.log(v)

    this.setState({ windowColor: v ?? null })
    this.setState({ windowheight: jsonObj.hmipage.height ?? "1050" })
    this.setState({ windowwidth: jsonObj.hmipage.width ?? "1890" })

    var pageShape = ShapeObjects(jsonObj);
    console.log("PageShapes ------------------------------------------------------------------")
    console.log(pageShape);
    emptyParamList();
    //////console.log(jsonObj.hmipage.template_id)

    if (jsonObj.hmipage.template_id != "") {
      //////console.log("-------------------------JsonTemplateID-----------------------------")
      //////console.log(jsonObj.hmipage.template_id)
      var templateShapes = [];
      // require('../' + this.props.termsAndCondition.pdfDocument);

      try {
        var value = require('C:/ECWEBSERVER/templates/' + jsonObj.hmipage.template_id + '.pagex');
      } catch {
      }

      // //////console.log(value)
      if (value != undefined) {
        //////console.log("Entered If "+value.default)
        await axios.get(value.default, {
          "Content-Type": "application/xml; charset=utf-8"
        }).then((response) => {
          //  //////console.log(response)
          // //////console.log('Your xml file as string', response.data);
          this.setState({ templateData: response.data }, () => {
            // //////console.log(this.state.templateData)
            //Template Convertion-----------------------------------------------------------------------
            var template = parser.getTraversalObj(this.state.templateData, options)
            var templateJson = parser.convertToJson(template, options);
            //////console.log("jsonTemplateObj--------------------------------------------------------------")
            //////console.log(templateJson)

            templateShapes = ShapeObjects(templateJson)
            ////console.log("TemplateShapes ------------------------------------------------------------------")
            ////console.log(templateShapes);
          })
        })
      } else {
        // //////console.log("NO File Detected!")
      }
      pageShape.map((val) => {
        templateShapes.push(val)
      })

      this.setState({
        shapes: templateShapes,
        loading: false
      }, () => {
      //  console.log(this.state.shapes)
      //   this.setState({
      //     loading: false
      //   })
      })
    } else {
   //   console.log(pageShape[0])
      this.setState({
        shapes: pageShape,
        loading: false
      }, () => {
        // console.log(this.state.shapes)
        // this.setState({
        //   loading: false
        // })
      })
    }
  }

  //Render Images---------------------------------------------------------------------
  renderImages(image, obj) {
    // const imageData = new window.Image();
    // if(image.filename.src != undefined)
    // {
    //   try{
    //     var value = require("./Images/"+image.filename.src);
    //   }catch(error)
    //   {
    //     //console.log(error)
    //   }
    //    if(value!= undefined)
    //    {
    //    imageData.src  = value.default;
    // //imageData.src =  "assets/"+image.filename.src;
    //   imageData.onload = () => {
    //     this.setState({
    //       image: imageData
    //     });
    //   };
    // }
    // }
    // return  <Image x={parseFloat(image.x)} y={parseFloat(image.y)}
    //  image={this.state.image}
    //   height={parseFloat(image.box.bottom)}
    //  width={parseFloat(image.box.right)} />
   return <UNCImage image={image} parent={obj} />;
  }
 
  renderparams(shape) {
     ////console.log("Params----------------------")
      if(shape.params.param.length == undefined)
      { 
         ////console.log(shape.params)
   //     ////console.log(shape.params)
      if(shape.params.param['name'] != undefined && shape.params.param['value'] != undefined)
        {
        addParam({"componentID":shape.params.param['componentID'],"name":shape.params.param['name'],"value":shape.params.param['value']});
       } 
      }else
      {
        shape.params.param.map((param)=>{
       //  ////console.log(param)
         if(param['name'] != undefined && param['value'] != undefined)
         {
          addParam({"componentID":param['componentID'],"name":param['name'],"value":param['value']});
         }
        });
      }
  }
  renderindex(i)
  {
    //console.log(i)
  }

  //Render Shapes --------------------------------
  renderShapes(shape, parentX, parentY ,parent) {
    // //////console.log(parentX)
    // //////console.log(parentY)
    if (shape) {
      if (shape.type != undefined) {
        switch (shape.type) {
          case "Rectangle":
            console.log("Can Rect")
            return <UNCRectangle shape={shape} parentX={parentX} parentY={parentY} parent={parent} />;
          case "Ellipse":
            return <UNCEllipse shape={shape} parentX={parentX} parentY={parentY} parent={parent} />;
          case "Pipe":
            return <UNCPipe shape={shape} parentX={parentX} parentY={parentY} parent={parent}/>;
          case "Line":
            return <UNCLine shape={shape} parentX={parentX} parentY={parentY} parent={parent} />;
          case "Polygon":
            return <UNCPolygon shape={shape} parentX={parentX} parentY={parentY} parent={parent}/>;
          case "Button":
            // return <UNCButton shape={shape} parentX={parentX} parentY={parentY} ProjectId={this.state.ProjectId} />
            return <Group>
              <Rect
                id={"Button" + shape.object.object_id + shape.object.object_number}
                x={parseFloat(parentX) + parseFloat(shape.box.axis_offset_left) + ((parseFloat(shape.box.left)) / 2)}
                y={parseFloat(parentY) + parseFloat(shape.box.axis_offset_top) + ((parseFloat(shape.box.top)) / 2)}
                width={parseFloat(shape.box.right)}
                height={parseFloat(shape.box.bottom)}
                fill={shape.button?.fill_color_up != undefined ? hextoRGBA(shape.button.fill_color_up) : "grey"}
                //Default Configuration 
                strokeWidth={1.5}
                stroke={"#eaeaea"}
                shadowColor={"grey"}
                shadowBlur={4}
                shadowOffsetX={3}
                shadowOffsetY={3}
                showOpacity={0.8}
                draggable={false}
                dashEnabled={true}
                dash={lineStyle(shape.line.style)}
                onClick={() => {
                  this.buttonOnclick(shape)
                }}
              />
              <Text
                align={"center"}
                width={parseFloat(shape.box.right)}
                height={parseFloat(shape.box.bottom)}
                fontSize={parseFloat(shape.button?.buttontext?.font_size) ?? 15}
                fill={shape.button != undefined ? hextoRGBA(shape.button?.buttontext?.color) : ""}
                x={parseFloat(parentX) + (parseFloat(shape.box.axis_offset_left) + (parseFloat(shape.box.left)) + parseFloat(0) / 2)}
                y={parseFloat(parentY) + parseFloat(shape.box.axis_offset_top) + ((parseFloat(shape.box.top)) + parseFloat(shape.box.bottom) / 2)}
                text={shape.button != undefined ? this.buttonText(shape.button.buttontext.text) : "Button"}
                draggable={false}
                onClick={() => {
                  this.buttonOnclick(shape)
                }}

              ></Text>
            </Group>


        }
      }
    }
  }

  buttonText(buttonTitle) {
    var text = buttonTitle;
    text = text.replace("&#xa;", " ");
    return text;
  }


  //Button Onclick---------------------
  buttonOnclick(shape) {
    if (shape.input_touch != undefined) {
      //////console.log(shape?.input_touch?.up?.command.__cdata)
      var cdata = shape?.input_touch?.up?.command.__cdata;
      cdata = cdata.split("(");

      if (cdata[0] == "openPage") {
        var targetPage = cdata[1].replace(")", "");
        targetPage = targetPage.replace(";", "").split(",")[0];
        //////console.log("targetPage : "+targetPage)
        try {
          var value = require('C:/ECWEBSERVER/Xml/' + targetPage + '.pagex');
        } catch {
        }
        if (value?.default != undefined) {
          this.handleSubmit(targetPage.toString());
        } else {
          alert(targetPage + " Not Found !");
        }
      }else if(cdata[0] == "messageBox")
      {
        alert(cdata[1].toString);
      }
    } else {
      //////console.log(shape?.button?.buttontext?.text)
    }

  }




  //Render Group-------------------------------------------------
  renderGroupsMian(shape, Obj) {
    // //////console.log(shape)
    // //////console.log(Obj)

    if (shape.group) {
      ////////console.log("-0-group")
      if (shape.group.length != undefined) {
        return shape.group.map((group) =>
          this.renderGroupsMian(group, Obj))
      } else {
        return this.renderGroupsMian(shape.group, Obj)

      }
    }

    if (shape.text) {
      ////////console.log("-0-text")
      if (shape.text.length != undefined) {
        return shape.text.map((text) => this.renderGrouptext(text, Obj))
      }
      else {
        return this.renderGrouptext(shape.text, Obj)
      }
    }

    if (shape.shape) {
      //   //////console.log(Obj.group)
      // //////console.log(Obj.x1)
      // //////console.log(Obj.y1)
      if (shape.shape.length != undefined) {
        return shape.shape.map((shape) =>
          this.renderShapes(shape, Obj.x1, Obj.y1 ,Obj))
      } else {

        return this.renderShapes(shape.shape, Obj, Obj.y1, Obj)
      }
    }


    if (shape.params) {
      //   //////console.log(Obj.group)
      // //////console.log(Obj.x1)
      // //////console.log(Obj.y1)
      ////console.log("Params--------------------------------")
      // if (shape.shape.length != undefined) {
      //   return shape.shape.map((shape) =>
      //     this.renderShapes(shape, Obj.x1, Obj.y1))
      // } else {

      //   return this.renderShapes(shape.shape, Obj, Obj.y1)
      // }
    }
  }


  //Direct Text-------------------
  rendertext(text, parentX, parentY,parent) {
    // ////console.log(text)
    return <UNCText text={text} parentX={parentX} parentY={parentY} parent={parent}/>;
  }



  //Group Text-------------------
  renderGrouptext(text, obj) {
    // var val = "";
    //  val = text.static_text;
    ////////console.log("groupText");
    ////////console.log(val)

    //Display Numeric----------------------------------------------
    // if (text.display_numeric != undefined) {
    //   val = text.display_numeric.expression.__cdata;
    //   //val = val.split("(");
    //   // //////console.log(val)
    // }

    //Display_on_off-----------------------------------------------
    // else if (text.display_on_off != undefined) {
    //   var cdataValue = text.display_on_off.__cdata;
    //   //this.timer = setInterval(() => this.displayOutput(),1000)  
    // }


    return <Text fontFamily={text.font_family}
      align={"center"}
      fontSize={text.font_size}
      fill={hextoRGBA(text.color)}
      // text={text.display_on_off != undefined ?
      //   this.state.display_on_off_value == true ? text.display_on_off.text_on : text.display_on_off.text_off :
      //   val}
      //draggable={true}
      text={text.static_text}

      x={parseFloat(obj.x1 ?? 0) - 5 + parseFloat(text.box.axis_offset_left) + parseFloat(text.box.axis_anchor) + (parseFloat(text.box.left)) + parseFloat(10)}
      y={parseFloat(obj.y1 ?? 0) + 5 + parseFloat(text.box.axis_offset_top) + parseFloat(text.box.axis_anchor) + ((parseFloat(text.box.top)) + parseFloat(20))}
    //  x={ parseFloat(obj.x1)+ parseFloat(text.box.axis_anchor)+parseFloat(text.box.axis_offset_left)+((parseFloat(text.box.left))/2)}
    //  y={ parseFloat(obj.y1)+parseFloat(text.box.axis_anchor)+parseFloat(text.box.axis_offset_top)+((parseFloat(text.box.top))/2)}
    />
  }

  //Labels Text ------------------------------------------------------------------
  renderLabels(text, obj,num) {
    console.log("renderLabel",num)
    return <UNCLabel text={text} parent={obj} />;
  }

  //Render--------------------------------------------------------------------------------------------------------------------------------------------
  render() {
    const { shapes, lables } = this.state;
    console.log(shapes)
    console.log(shapes.length)
    return (
   <div>
      <div id="stageContainer" width={this.state.windowwidth}
        height={this.state.windowheight} style={{ backgroundColor: this.state.windowColor }} >
        <Navbar bg="dark" variant="dark">
          <Navbar.Brand href="#home">
            <img
              src="assets/ecs.png"
              width="50"
              height="50"
              className="d-inline-block align-top"
            /></Navbar.Brand>
          <Nav className="mr-auto">
            <Nav.Link href="#" onClick={() => this.handleSubmit("Home_Page")}>Home</Nav.Link>

            {/* Dynamic Retriving of Xmls from the Folder -----------------------------------------------------------   */}
            <NavDropdown title="Xml's" style={{ backgroundolor: 'white' }} >
              {
                this.state.xmlsList.map((xml, i) => {
                  // var name = xml.default.replace("/static/media/", "");
                  // name = name.replace(".pagex", "");
                  // name = name.split(".");

                  return <NavDropdown.Item className={i + 1} href="#" onClick={() => this.handleSubmit(xml[0])}>{xml[0]}</NavDropdown.Item>
                }
                )
              }
            </NavDropdown>
            {/* <Button variant="primary">{this.state.ProjectId}</Button>{' '} */}
          </Nav>
          <Form inline>
            {/* <Button variant="outline-info">LatestAlarms</Button>{' '} */}
            {/* <Button variant="outline-info">LatestEvents</Button>{' '} */}
           <a href="/adminDashboard"> <Button variant="outline-info" >Dashboard</Button></a>
          </Form>
        </Navbar>
        <center><div style={{ display: this.state.loading ? "block" : "none" }}>
          <label>Loading...</label>
        </div></center>

        {this.state.currentXml === "Home_Page" ?

          //Home Page----------------------------------
          <div  style={{ width: window.width, height: window.height, background: "#004C99" }}>
           <br />
            <div >
              <center><h3 style={{ color: 'white' }}>Welcome To ECSCADA Design Studio</h3></center>
            </div>
            <br />
            <br/>
            <br/>
            <div class="container">
              <div class="row">

                {this.state.xmlsList.map((page) => {
                  // var pageName = page.default.split("/")
                  // pageName = pageName[3].split(".")
                  // pageName = pageName[0]
                  return <div class="col-md-3 text-center" style={{
                    paddingBottom: '30px',

                  }}>
                    <Button style={{ width: "100%" }} onClick={() => this.handleSubmit(page)} variant="btn btn-secondary btn-lg">
                      <p style={{ fontSize: "15px" }}>
                        {page}
                      </p>

                    </Button>

                  </div>

                })}

              </div></div>
          </div>
          :

          <Stage
            id="konvaStage"
            ref={this.myRef}
            width={this.state.windowwidth}
            height={this.state.windowheight}
            containerId={"stageContainer"}
            //  style={{marginLeft:"250px", backgroundColor:"Grey"}}

            style={{ display: this.state.loading ? "none" : "block", backgroundColor: this.state.windowColor }}
          >

            <Layer>
              {shapes.length != undefined ? shapes.map((obj, num) => obj != undefined ?
                (
                  <Group
                    key={"Grp_" + obj.objectNumber + num}

                    // id={obj.objectNumber}
                    x={0}
                    y={0}
                  // width={parseFloat(obj.x2 == undefined ? 0 : obj.x2)}
                  // height={parseFloat(obj.y2 == undefined ? 0 : obj.y2)}
                  // fill={"blue"}
                  //draggable={true}
                  >
                   

                    {/* obj.shape--------------------------------------------------------- */}
                    {obj.shape === undefined ? (
                      <Group />
                    ) : (
                      obj.shape.length != undefined ?
                        obj.shape.map((shape) =>
                          this.renderShapes(shape, obj.x1, obj.y1 , obj)
                        ) : this.renderShapes(obj.shape, obj.x1, obj.y1,obj)
                    )}


                    {/* obj.shapes--------------------------------------------------------- */}
                    {obj.shapes === undefined ? (
                      <Group />
                    ) : (
                      obj.shapes.map((shape) =>
                        this.renderShapes(shape, obj.x1, obj.y1 , obj)
                      )
                    )}

                    {obj.params === undefined ? (
                      <Group />
                    ) : (
                      // obj.params.length != undefined ?
                      // obj.params.map((shape) =>
                      //   this.renderparams(shape)
                      // ): 
                      this.renderparams(obj)
                    )}



                    {/* Obj.text----------------------------------------------------------- */}

                    {/* {obj.text === undefined ?(
                  <Group />
                ):
                obj.text.length != undefined ? 
                 obj.text.map((value) => {

                  //////console.log("*****************************************************************************")
                  return  <UNCDynamicText shape={value} parentX={obj.x1} parentY={obj.y1} />
                 }
                  ):   <UNCDynamicText shape={obj.text} parentX={obj.x1} parentY={obj.y1} />
                } */}

                    {obj.text === undefined ? (
                      <Group />
                    ) :
                      obj.text.length != undefined ?
                        obj.text.map((value) => this.rendertext(value, obj.x1, obj.y1,obj)
                        ) : this.rendertext(obj.text, obj.x1, obj.y1,obj)
                    }


                    {/* //Obj.Labels---------------------------------------------------- */}
                    {obj.labels === undefined ? (
                      <Group />
                    ) : (
                      //MainLabels length Validation
                      obj.labels.length != undefined ?
                        //if
                        obj.labels.map((text, i) =>
                          text.text.length != undefined ?
                            text.text.map((text) =>
                              this.renderLabels(text, obj,i))
                            : this.renderLabels(text.text, obj,i))
                        //else
                        : obj.labels.text.length != undefined ?
                          obj.labels.text.map((text, i) =>
                            this.renderLabels(text, obj,"obj.labels.text.map")
                          )
                          : this.renderLabels(obj.labels.text, obj,"obj.labels.text.map")
                    )}

                    {/* //obj.groups-------------------------------------------------------- */}

                    {

                      obj.group === undefined ? (
                        <Group />
                      ) : (
                        //if--1--------------------

                        obj.group.length != undefined ?
                          obj.group.map((val) => {
                            //////console.log("--GroupS in  UNCCanvas")
                            //////console.log(obj)
                            if (val.text) {
                              //   //////console.log("-0-text")
                              //  //////console.log(obj)
                              if (val.text.length != undefined) {
                                return val.text.map((text) => this.rendertext(val.text, obj.x1, obj.y1,obj))

                              }
                              else {
                                return this.rendertext(val.text, obj.x1, obj.y1,obj)
                              }
                            }
                            if (val.group) {
                              ////////console.log("-0-group")
                              if (val.group.length != undefined) {
                                //  //////console.log("Calling");
                                return val.group.map((group) => this.renderGroupsMian(group, obj))
                              }
                              else {
                                return this.renderGroupsMian(val.group, obj)
                              }
                            }
                            if (val.shape) {
                              //////console.log("-0-shape")
                              //////console.log(obj.group.x1, obj.group.y1)
                              //////console.log(val.x1, val.y1)
                              if (val.shape.length != undefined) {
                                return val.shape.map((shape) =>
                                  this.renderShapes(shape, obj.x1, obj.y1 , obj))
                              }
                              else {
                                return this.renderShapes(val.shape, obj.x1, obj.y1 , obj)
                              }
                            }
                          }
                          ) : this.renderGroupsMian(obj.group, obj)
                      )}


                    {/* //obj.images-------------------------------------------------------- */}

                    {obj.image === undefined ? (
                      <Group />
                    ) : (
                      obj.image.length != undefined ?
                        obj.image.map((image) =>
                          this.renderImages(image, obj)
                        ) :    this.renderImages(obj.image, obj)
                    )}

                  </Group>
                ) : null) : null}

            </Layer>
          </Stage>
        }
      </div>
      </div>
    );
  }
}

export default UNCCanvas;