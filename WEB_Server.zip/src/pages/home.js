import React,{ useState } from 'react';
import {Link} from 'react-router-dom';
import { Base64 } from 'js-base64';



export default function Login() {
    const [username, setUsername]=useState("");
    const [password, setPassword]=useState("");
    const [userdetails,setuserdetails]=useState([]);
    console.log(Base64.encode("UmFqa3VtYXJAMTIz"))

    React.useEffect(() => {


        fetch(process.env.REACT_APP_IP+"api/userdetail?userid=0")
          .then(results => results.json())
          .then(data => {
            setuserdetails(data)
            console.log(data)
          });
      }, []); // <-- Have to pass in [] here!
  
async function login() {

    //let item = { username,password };
    //console.log(username)
   
   
        console.log(username)
       
      
       userdetails.map((a=>{
        if(a.Username ===  username && a.Password === password ){
       
        sessionStorage.setItem("UserId",a.UserID)
        sessionStorage.setItem("user",username)
        if(a.RoleID === 1){
        sessionStorage.setItem("Admin",a.RoleID)
        }
       
    }
    return null;
    }))
    if(sessionStorage.getItem("user")){
        window.location.assign("adminDashboard");  
    }
        else if(username == '') {
           
           alert("Please enter valid username ")
        }
        else if(password == '') {
            
           alert("Please enter valid  pasword")
        }
        else {
            //console.log(response.status)
           alert("Please enter valid username and pasword")
        }
    

}

        return(
            
            <div>
                <body className="font-montserrat">
                <div className="auth">
    <div className="auth_left">
        <div className="card">
            <div className="text-center mb-2">
               
            </div>
			 <div className="card-body">
			 <h3 style={{textAlign:"center"}}> ECSCADA Web Server Application </h3>
			 </div>
            <div className="card-body">
			<img className="text-center mb-2" src="assets/images/ecillogo.jpg"  style={{width:"150px",height:"170px",marginLeft:"75px"}} alt=""/>
                <div className="card-title" style={{textAlign: "center"}}>Login to ECSCADA Application</div>
                
					<div className="form-group">
                    <input type="text"   maxLength="25"  aria-describedby="username" className="form-control" id="inp" name="input" placeholder="Username" onChange={(e)=>setUsername(e.target.value)}/>
                </div>
                <div className="form-group">
                   
                <input type="password"   maxLength="25"  onKeyPress={(e) => e.key === 'Enter' && login()}  placeholder="Password" className="form-control" id="exampleInputPassword1" onChange={(e)=>setPassword(Base64.encode(e.target.value))}/>
					 {/* <label className="form-label"><a href='/ForgotPassword' className="float-right small">I forgot password</a></label> */}
                </div>
               
                <div className="form-group">
                   
                 <Link  onClick={login}   className="btn btn-primary btn-block"  > Sign in</Link> 
                </div>
            </div>


        </div>        
    </div>

    <div className="auth_right full_img" ></div>
   
</div>


</body>
            </div>

        );
     }
//  }

// export default Login;