
const config = {
    user :'sa',
    password :'scada123',
    server:'localhost',
    database:'ECDBAZE',
    options:{
//         trustedconnection: true,
         enableArithAbort : false, 
//         instancename :'SQLEXPRESS'
     },
        port :1433
}

module.exports = config; 