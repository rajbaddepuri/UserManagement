import { Line,Group } from "react-konva";
import { getPipePoints } from "./CanvasUtils.js";
import { useState } from 'react';
import axios from 'axios';
import {
  Rect,
  Text,
  
} from "react-konva";
import { hextoRGBA,androidToRgba, lineStyle ,gradientStartPoints ,gradientEndPoints,getTagValueApi } from './Utils';


const UNCPipe = (shapeElement) => {
  const { shape, parentX, parentY } = shapeElement;

  const [hide, setHide] = useState(0);
  const [dynamcifill, setDynamicFill] = useState(0);



  //hidden_When-------------------------------------------------------------------------------------
  if (shape.object.security != undefined) {
    var value = shape.object.security.hidden_when.__cdata;
     axios({
       method: 'post',
       url: getTagValueApi,
       headers: {}, 
       data: {
         tagname:value, // This is the body part
       }
     }).then((res)=>{
       ////console.log(res.data.tagValue)

    if(res.data.tagValue > 50)
    {
     setHide(true)
     ////console.log("Visible")
    }else{
     setHide(false)
     ////console.log("Not Visible")
    }

     });

  }
  // -0---GRADIENT_LEFT_TO_RIGHT-------------------------------
  //startPoint:   {x1:x2/2 - x2/4 , y1:y2}
  //endPoint:     {x2:x2 - x4/4,y2:y2 }

  //-1--GRADIENT_RIGHT_TO_LEFT----------------------------------
  //startPoint:  {x1: x2 - x2/4   , y1:y2   }
  //endPoint:    {x2: x2/2 - x2/4 , y2:    y2  }

  //--2---GRADIENT_TOP_TO_BOTTOM -----------------------------
  //startPoint:  {x1: x2    , y1:y2 - y2/4  }
  //endPoint:    {x2: x2 , y2:y2/2 - y2/4  }

  //--3---GRADIENT_BOTTOM_TO_TOP  -----------------------------
  //startPoint:  {x1: x2    , y1:y2/2 - y2/4  }
  //endPoint:    {x2: x2 , y2:y2 - y2/4  }

  //--4--GRADIENT_HORIZONTAL_TO_MIDDLE -------------------------
  //startPoint:  {x1: x2    , y1:y2/2 }
  //endPoint:    {x2: x2 , y2:y2/2 + 1  }

  //---
  //---5---GRADIENT_HORIZONTAL_FROM_MIDDLE ---------------------
  //startPoint:  {x1: x2    , y1:y2/2 }
  //endPoint:    {x2: x2 , y2:y2 - 1  }

  //--6---GRADIENT_VERTICAL_TO_MIDDLE----------------------------
  //startPoint:  {x1: x2/2   , y1:y2 }
  //endPoint:    {x2: x2/2 -1 , y2:y2 }

  //---
  //--7--GRADIENT_VERTICAL_FROM_MIDDLE----------------------------
  //startPoint:  {x1: x2/2   , y1:y2 }
  //endPoint:    {x2: x2 -1 , y2:y2 }






  return (
    <Group>
      
    <Line
      key={"Pipe_" + shape.object.object_number}
      id={"Pipe_" + shape.object.object_id}
      points={getPipePoints(shape, parentX, parentY)}
      visible={shape.object.security != undefined ? hide : true}
      stroke={hextoRGBA(shape.pipe.lowlight_color)}
      strokeWidth={parseFloat(shape.pipe.pipe_width)}
      // closed={"true"}
      // shadowColor={hextoRGBA(shape.pipe.lowlight_color)}
      // shadowBlur={10}
      // shadowForStrokeEnabled={true}
      // shadowOffsetX={0}
      // shadowOffsetY={0}
      // showOpacity={100}

      dashEnabled={false}
      dash={lineStyle(shape.line.style)}


    />
      <Line
      // key={"Pipe_" + shape.object.object_number}
      // id={"Pipe_" + shape.object.object_id}
      points={getPipePoints(shape, parentX, parentY)}
      visible={shape.object.security != undefined ? hide : true}
      stroke={hextoRGBA(shape.pipe.highlight_color)}
      strokeWidth={parseFloat(shape.pipe.pipe_width) / 3}
      // closed={"true"}
      // shadowColor={hextoRGBA(shape.pipe.lowlight_color)}
      // shadowBlur={10}
      // shadowForStrokeEnabled={true}
      // shadowOffsetX={0}
      // shadowOffsetY={0}
      // showOpacity={100}

      dashEnabled={false}
      dash={lineStyle(shape.line.style)}


    />
    </Group>
  );
};

export default UNCPipe;
