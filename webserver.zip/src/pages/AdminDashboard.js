import React,{Component} from 'react';
import {Link} from 'react-router-dom';
import IP from './Utiltys';


class AdminDashboard extends React.Component{
    constructor(props){
        super(props);
        this.state={
          ModelsCount: 0,
          eventsCount:0,
          alarmsCount:0
        }
      }

      componentDidMount(){

             
       

        // Fectch Users--------------------
   const fetcheventsApi = process.env.REACT_APP_IP+"api/EventsAlarms";

    fetch(fetcheventsApi)
      .then(res => res.json())
      .then(
        (result) => {
            console.log("Length of Users :" + result.length)
          this.setState({
            eventsCount: result.length
          });
        },
        (error) => {
       
        }
      )

     //Fetch Projects -------------------------------------
     const fetchalarmsApi = process.env.REACT_APP_IP+"api/alarms";

     fetch(fetchalarmsApi)
       .then(res => res.json())
       .then(
         (result) => {
             console.log("Length of alarms :" + result.length)
           this.setState({
            alarmsCount: result.length
           });
         },
         (error) => {
        
         }
       )
    }

    render(){
        return(
         
            <body className="font-montserrat"> 
           <div>
            {/* <div className ="page-loader-wrapper">
                <div className="loader">
                </div>
            </div> */}
            
            <div id="main_content">
              
               
            
                <div className="page">
                 
                  <div className="section-body mt-3">
                        <div className="container-fluid">
                            <div className="row clearfix">
                                <div className="col-lg-12">
                                    <div className="mb-4">
                                        <h4>Welcome to ECSCADA WEBSERVER</h4>
                                       
                                    </div>                        
                                </div>
                            </div>
                            <div className="row clearfix row-deck">
                             
                                <div className="col-xl-4 col-lg-5 col-md-6">
                                    <div className="card">
                                        <div className="card-header">
                                            <h3 className="card-title">Alarms</h3>
                                        </div>
                                        <div className="card-body">
                                            <h5 >Total No. of Alarms - {this.state.alarmsCount}</h5>
                                            <span className="font-12"><Link to='/ViewAlarms'>View Alarms </Link></span><br/><hr/>
                                            {/* <span className="h7"><i className="fa fa-arrow-circle-left"> </i>18-12-2020<i className="fa fa-arrow-circle-right"></i></span> */}
                                        </div>
                                    </div>
                                </div>
                                <div className="col-xl-4 col-lg-5 col-md-6">
                                    <div className="card">
                                        <div className="card-header">
                                            <h3 className="card-title">Events</h3>
                                        </div>
                                        <div className="card-body">
                                            <h5 >Total No. of Events - {this.state.eventsCount}</h5>
                                            <span className="font-12"><Link to='/ViewEvents'>View Events </Link></span><br/><hr/>
                                            
                                        </div>
                                    </div>
                               </div>
                               <div className="col-xl-4 col-lg-5 col-md-6">
                                    <div className="card">
                                        <div className="card-header">
                                            <h3 className="card-title">Models</h3>
                                        </div>
                                        <div className="card-body">
                                            <h5 >Total No. of Flow Models - 33</h5>
                                            <span className="font-12"><Link to='/'>View Models </Link></span><br/><hr/>
                                            
                                        </div>
                                    </div>
                               </div>
 







                    
                </div>    
            </div>
            
          </div> </div>
           </div>
           </div>
       </body>
        );
    }
}
export default AdminDashboard;