class ShapesDataUtil extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
}

export default ShapesDataUtil;
