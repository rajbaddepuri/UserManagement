


const initailState={
  data:[],
  datalist:[],
  chartoption:[],
 
}


  const counterReducer=(state=initailState,action)=>{
    switch(action.type){
      case "datalist":
        //console.log(action.payload)
        return{
          ...state,
          datalist: action.payload
      }
      case "chartoption":
        
        return{
          ...state,
          chartoption: action.payload
      }

  
        default:
            return state;
    }
  
  }

  export default counterReducer;

  