
import express from 'express';
import cron from 'node-cron'
import bodyParser from 'body-parser'
import cors from 'cors'
import sql from 'mssql'
import * as fs from 'fs';
//import * as fs from 'graceful-fs';
import * as path from 'path';
import moment from 'moment';
import { } from 'dotenv/config'
import { error } from 'console';

var app = express();
var router = express.Router();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
app.use('/api', router);

router.use((request, response, next) => {
  //console.log('middleware');
  next();
})

app.get("/", (req, res) => {
  res.json({ message: "Welcome to ECSCADA application." });
});


const config = {
  user: 'sa',
  password: 'scada123',
  server: 'localhost',
  database: 'ECDBAZE',
  options: {
    //         trustedconnection: true,
    enableArithAbort: false,
    //         instancename :'SQLEXPRESS'
  },
  port: 1433

  //  user: 'sa',
  //  password: 'scada123',
  //  server: 'localhost', 
  //  database: 'ECDBAZE',
  //  synchronize: true,
  //  trustServerCertificate: true,
}

app.post("/Expeval", (req, res) => {
  //console.log("rajkumar entered");
  let order = { ...req.body };
  //console.log(order["InputScript"])
  sql.connect(config, function (err) {
    // create Request object
    var request = new sql.Request();
    ////console.log("entered into sql");
    let quer2 = `select '_'+pointname as pointname,fvalue,pttype,state from WEBDATA;`
    request.query(quer2, function (err, recordset) {
      if (recordset != undefined) {
        let dt = recordset.recordset
        //console.log("veraa0",dt);
        ////console.log(dt);
        //var temp = (handshakeData._query['foo']);
        var temp = order["InputScript"];
        temp = temp.replace("$;", "");
        //_DTms_0003+2+_DTms_0004/_DTms_0005;
        //console.log(temp);
        ////console.log("dgshfh",dt.length);
        var b = temp.toString();
        for (let i = 0; i < dt.length; i++) {
          var TagName = dt[i]["pointname"].toString();
          // console.log("pttype",dt[i]["pttype"]);
          var pttype = dt[i]["pttype"];
          //console.log("pttype",pttype);
          //console.log("tagname",TagName);
          if (pttype == 1) {   //analog
            // console.log("entered into analog");
            var fvalue = dt[i]["fvalue"].toString();
          }
          if (pttype == 2) {  //digital
            // console.log("entered into digital")
            var fvalue = dt[i]["state"].toString();
          }
          if (temp.toString().includes(TagName)) {
            b = b.replace(TagName, fvalue);
            temp = b.toString();
          }
        }
        try {
          //console.log("raj",temp)
          var result = eval(temp);
          if (result != undefined) {
            const response = {
              "data": result.toString() == "true" ? "True" : result.toString() == "false" ? "False" : result.toString(),
              "error": "false"
            };
            //   console.log(response)
            res.json(response);
          }
        }
        catch {
          //console.log("entere into catch")
          const response = {
            "data": null,
            "error": "true"
          };
          //console.log(response)
          res.json(response);
        }
      }
    })
  })
})

app.get('/listofmimics', function (req, res) {
  const directoryPath = path.join(process.env.MIMIC_Path);
  //passsing directoryPath and callback function
  fs.readdir(directoryPath, function (err, files) {
    //handling error
    if (err) {
      return console.log('Unable to scan directory: ' + err);
    }
    var mimicsList = files.filter(m => path.extname(m) == '.pagex');
    var filteredMimicList = [];
    if (mimicsList != null && mimicsList.length > 0) {
      mimicsList.forEach(function (filename) {
        filteredMimicList.push(filename.replace(".pagex", ""));        
      });
    }
    res.send(filteredMimicList);
    //return mimicsList;
    //console.log(mimicsList)
  });
});
///---------- Send mimic file content --------------///
app.get('/mimic', function (req, response) {
  let mimic_name = req.query["mimic_name"]
 // console.log(req.query)
  var path = process.env.MIMIC_Path + mimic_name +'.pagex';
  var output = fs.readFileSync(path, 'utf8');
  response.type('application/xml');
  response.send(output);
});

/// ...............Web REports For Mobile..............///
app.post("/webreports", (req, res) => {
  let body = req.body;
  let path = process.env.REPORT_PATH;
  console.log(path);
  if (body["path"] == "daily") {
    console.log("inside webreports: " + path);
    const directoryPath = path + "/" + "daily";
    fs.readdir(directoryPath, function (err, files) {
      if (err) {
        res.status(500).send({
          message: "Unable to scan files!",
        });
      }
      console.log(files);
      let fileInfos = [];
      for (let i = 0; i < files.length; i++) {
        console.log(body["date"]);
        if ((files[i].toString()).includes(body["date"])) {
          fileInfos.push({
            name: files[i],
            path: "daily",
          });
        }
      }
      console.log(fileInfos);
      res.status(200).send(fileInfos);
    });
  }
  else if (body["path"] == "shift") {
    const directoryPath = path + "/" +"shift";
    fs.readdir(directoryPath, function (err, files) {
      if (err) {
        res.status(500).send({
          message: "Unable to scan files!",
        });
      }
      let fileInfos = [];
      for (let i = 0; i < files.length; i++) {

        if ((files[i].toString()).includes(body["date"])) {

          fileInfos.push({
            name: files[i],
            path: "shift",
          });
        }
      }
      console.log(fileInfos)
      res.status(200).send(fileInfos);
    });
  }
})
/////////////////////////////////////////////////////////////////////////////
app.get('/reports', function (req, response) {
     console.log("inside Reports:");
  let fileName = req.query["report_name"];
  let reportType = req.query["report_type"];
  console.log(fileName, reportType);
  var path = process.env.REPORT_PATH + reportType + "/" + fileName;
     console.log(path);
  if (fileName.includes(".pdf")) {
    console.log("Generating PDF");
    try {
      console.log("before creating pdf read stream");
      var rs = fs.createReadStream(path);
      var stat = fs.statSync(path);
      console.log("stat.size below");
      console.log(stat.size);
      response.setHeader('Content-Length', stat.size);
      response.setHeader('Content-Type', 'application/pdf');
      response.setHeader('Content-Disposition', 'attachment; filename=download.pdf');
      //response.setHeader('Content-Disposition', 'inline; filename=download.pdf');
      //response.statusCode = 202;
      rs.pipe(response);
      console.log("after pipe");
      //rs.unpipe(response);
      console.log("after UNpipe");
    }
    catch (err) {
      console.log("inside catch");
      console.log(err.stack);
    }
    finally {
      //file.close();
    }
  }
  else if (fileName.includes(".xlsx") || fileName.includes(".xls"))
  {
    console.log("Generating EXCEL");
    try {
      console.log("before creating excel read stream");
      var rs = fs.createReadStream(path);
      var stat = fs.statSync(path);
      console.log("stat.size below");
      console.log(stat.size);
      response.setHeader('Content-Length', stat.size);
      response.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      response.setHeader('Content-Disposition', 'attachment; filename=download.xlsx');
      //response.setHeader('Content-Disposition', 'inline; filename=download.pdf');
      //response.statusCode = 202;
      rs.pipe(response);
      console.log("after pipe");
      //rs.unpipe(response);
      console.log("after UNpipe");
    }
    catch (err) {
      console.log("inside catch");
      console.log(err.stack);
    }
    finally {
      //file.close();
    }
  }

});

///////////---for user deletion ----- //////
app.get('/deleteuser', function (req, res) {
  let User_Id = req.query["User_Id"]
  console.log(User_Id)
 
  try{
    var request = new sql.Request();
    sql.connect(config, function (err) {
      let quer1 =  `delete from UsersMapToProjects where UserID ='${User_Id}';`;
      request.query(quer1, function (err, response) {
        sql.connect(config, function (err) {
          let quer2 =  `delete from UserDetails where UserID ='${User_Id}';`;
      request.query(quer2, function (err, response) {
        res.send("User Deleted Succesfully")
      })
        })
      })
    })
}
  catch{
    res.send("Data Base error");
  }
 
});

app.get('/handShake', function (req, res) {

  res.send("connected")

})


var port = process.env.PORT;
app.listen(port);
console.log('Ecscada API is runnning at ' + port);



