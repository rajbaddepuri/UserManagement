import React,{Component} from 'react';
import {Link} from 'react-router-dom';


/* import {BrowserRouter as Router ,Route,Switch} from 'react-router-dom'; */




class Sidebar extends React.Component{
    
    constructor(props) {
    super(props);

        
    this.state = {
       data: 'Dashboard'
    }
    this.updateAdmin=this.updateAdmin.bind(this)
    this.updateState = this.updateState.bind(this);
    this.modelState = this.modelState.bind(this);
    this.UpdateAlarms = this.UpdateAlarms.bind(this);
    this.UpdateEvents = this.UpdateEvents.bind(this);
    this.UpdateReports = this.UpdateReports.bind(this);
    this.UpdateProfile = this.UpdateProfile.bind(this);
    this.UpdateSettings = this.UpdateSettings.bind(this);
    this.UpdateHelp = this.UpdateHelp.bind(this);
    this.UpdateContact = this.UpdateContact.bind(this);
    this.UpdateChangePassword = this.UpdateChangePassword.bind(this);
 };

     updateAdmin() {
         
    this.setState({data: 'Dashboard'})
    this.updateAdmin = this.updateAdmin.bind(this);
}

 updateState() {  
     this.setState({data: 'Process Flow Models'})
     this.updateState = this.updateState.bind(this);
     window.location.assign('/processflow')
 }

 modelState() {
    this.setState({data: 'Trends'});
    this.modelState = this.modelState.bind(this);
    window.location.assign('/AreaTrends')
    
}

UpdateAlarms()
{
    this.setState({data: 'Alarms'});
    this.UpdateAlarms = this.UpdateAlarms.bind(this);
    
}


UpdateEvents()
{
    this.setState({data: 'Events'});
    this.UpdateEvents = this.UpdateEvents.bind(this);
    
}


UpdateReports()
{
    this.setState({data: 'Reports'});
    this.UpdateReports = this.UpdateReports.bind(this);
    
}

UpdateSettings()
{
    this.setState({data: 'Settings'});
    this.UpdateSettings = this.UpdateSettings.bind(this);
    
}

UpdateProfile()
{
    this.setState({data: 'My Profile'});
    this.UpdateProfile = this.UpdateProfile.bind(this);
    
}

UpdateHelp()
{
    this.setState({data: 'Need Help?'});
    this.UpdateHelp = this.UpdateHelp.bind(this);
    
}

UpdateContact()
{
    this.setState({data: 'Contact Us'});
    this.UpdateContact = this.UpdateContact.bind(this);
    
}
UpdateChangePassword()
{
    this.setState({data: ' Change Password'});
    this.UpdateChangePassword = this.UpdateChangePassword.bind(this);
    
}
      /*  shoot(a) {
         alert(a);
        };
   
    handleClick = () => {
        console.log("Button clicked...")
    } */

        
    render(){

        return(
            <body className="font-montserrat" >
           <div>
          
            <div id="header_top" className="header_top">
            <div className=".sidebar-opposite-hide">
        <div className="container">
      
            <div className="hleft">
              
                <div className="dropdown"><br/><br/>
                
              
    
      
          
                <div className="icon menu_toggle mr-3">
                
                       <Link  onClick = {this.updateAdmin} to='/AdminDashboard' class="nav-link icon xs-hide"><i className="fa fa-tachometer"  data-toggle="tooltip" data-placement="right" title="Dashboard" ></i></Link >                    
                       <a href='/processflow' className="nav-link icon app_file xs-hide"><i className="fa fa-file-code-o" data-toggle="tooltip" data-placement="right" title="Processflowmodel"></i></a>
                    <Link  onClick = {this.modelState} to='/AreaTrends' class="nav-link icon xs-hide"><i className="fa fa-bar-chart"  data-toggle="tooltip" data-placement="right" title="Dashboard" ></i></Link >              
                    <Link  onClick = {this.UpdateAlarms} to='/VIewAlarms'  class="nav-link icon xs-hide"><i className="fa fa-bullhorn"  data-toggle="tooltip" data-placement="right" title="Alarms"></i></Link >
                    <Link  onClick = {this.UpdateEvents} to='/ViewEvents' class="nav-link icon app_file xs-hide"><i className="fa fa-clock-o"  data-toggle="tooltip" data-placement="right" title="Events"></i></Link >
                    {/* <Link  onClick = {this.UpdateReports} to='/LogReports' class="nav-link icon theme_btn xs-hide"><i className="fa fa-file" data-toggle="tooltip" data-placement="right" title="Reports"></i></Link >
                    <Link  onClick = {this.UpdateSettings} to='/Settings' class="nav-link icon app_file xs-hide"><i  className="fa fa-gear"  data-toggle="tooltip" data-placement="right" title="Settings"></i></Link > */}
                    <Link  onClick = {this.UpdateProfile} to='/Profile' class="nav-link icon app_file xs-hide"><i className="fe fe-user"  data-toggle="tooltip" data-placement="right" title="My Profile"></i></Link >
                    <Link  onClick = {this.UpdateReports} to='/Report_daily' class="nav-link icon theme_btn xs-hide"><i className="fa fa-file" data-toggle="tooltip" data-placement="right" title="Reports"></i></Link >
                    <Link  onClick = {this.UpdateChangePassword} to='/ChangePassword' class="nav-link icon app_file xs-hide"><i className="fa fa-key"  data-toggle="tooltip" data-placement="right" title="Change Password"></i></Link >
                              
                     </div>
                </div></div>
            </div></div>            
 
            <div id="left-sidebar" className="sidebar-nav ">
            <nav id="left-sidebar-nav" className="sidebar-nav" >
            <div className="right">
                <Link className="icon menu_toggle mr-3 float-right" ><i  className="fa fa-window-close "></i></Link>
            </div>
          
            <img src="assets/images/ecillogo.JPG" style={{width:"170px", height:"200px", marginLeft:"0px"}} alt=""/>
          
            <hr/>
        
             <h5 class="brand-name"><a href="javascript:void(0)" class="menu_option float-right"><i  onclick="gridView()" class="icon-grid font-16" data-toggle="tooltip" data-placement="left" title="Grid & List Toggle"></i></a></h5>

                    <ul className="metismenu" style={{marginTop:"45px"}} >
                                                               
                        <li><Link onClick = {this.updateAdmin}  to="/AdminDashboard"><i className="fa fa-tachometer"></i><span>Dashboard</span></Link></li>
                        <li><a href='/processflow' onclick={this.UpdateProcessFlow} ><i className="fa fa-file-code-o"></i><span>Project Flow Model</span></a></li>
                          <li><Link  onClick = {this.modelState} to='/AreaTrends' ><i className="fa fa-bar-chart"></i><span>Trends</span></Link></li>
                        <li><Link to="/ViewAlarms"  onClick = {this.UpdateAlarms}><i className="fa fa-clock-o"></i><span>Alarms</span></Link> </li>
                        <li><Link to="/ViewEvents"  onClick = {this.UpdateEvents}><i className="fa fa-clock-o"></i><span>Events</span></Link></li>
                        <li><Link to="/Profile"  onClick = {this.UpdateProfile}><i className="fa fa-user"></i><span>My Profile</span></Link></li>
                        <li><Link to="/Report_daily"  onClick = {this.UpdateReports}><i className="fa fa-file"></i><span>Reports</span></Link></li>
                        <li><Link to="/ChangePassword"  onClick = {this.UpdateChangePassword}><i className="fa fa-key"></i><span>Change Password</span></Link></li>
                          
                        
                    </ul>
              
                    
                </nav>        
            </div>
            </div></div>

                    
    <div className="page">
    <div id="page_top" className="section-body top_dark">
        <div className="container-fluid">
            <div className="page-header">
                <div className="left">
                    <Link className="icon menu_toggle mr-3"><i className="fa  fa-align-left"></i></Link>
                    {this.state.data} 
                    <h1 className="page-title"></h1>                        
                </div>
                

                <div className="right">
                    
                    <div className="notification d-flex">
                   <div className="dropdown d-flex">
                            <div className="nav-link icon d-none d-md-flex btn btn-default btn-icon ml-2" data-toggle="dropdown"><i className="fa fa-user" style={{color:"white"}} > Loged in as : {sessionStorage.getItem("user")}</i></div>
                            <div className="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <Link to='/Profile' className="dropdown-item" ><i className="dropdown-icon fe fe-user"></i> Profile</Link>
                                <a href='/' className="dropdown-item" ><i className="dropdown-icon fe fe-log-out"></i> Sign out</a>
                            </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
   </div>

            </body>
        );
    }
}
    export default Sidebar;