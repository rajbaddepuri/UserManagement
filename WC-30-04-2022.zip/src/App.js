import React,{Components} from 'react';
import './App.css';
import Home from './pages/home';
import AdminDashboard from './pages/AdminDashboard';
import TabularTrends from './pages/TabularTrends';
import ViewEvents from './pages/ViewEvents';
import HistoricEvents from './pages/HistoricEvents';
import ForgotPassword from './pages/ForgotPassword';
import ViewAlarms from './pages/ViewAlarms';
import HistoricAlarms from './pages/HistoricAlarms';
import Profile from './pages/Profile'
import Settings from './pages/Settings';
import Sidebar from './components/Sidebar'; 
import Footer from './components/Footer'; 
import FileUpload from './pages/FileUpload'; 
import {BrowserRouter as Router ,Route,Switch} from 'react-router-dom';
import Graph from './pages/Areagraph';
import Report_daily from './pages/Report_daily';
import Report_shift from './pages/Report_shift';
import HistGraph from './pages/Histgraph';
import UNCCanvas from './pages/Xml/UNCCanvas'
import ChangePassword from './pages/ChangePassword';
import TrendGraph from './graph'
//import SupervisorDashboard from './pages/SupervisorDashboard';
//import EmployeeDashboard from './pages/EmployeeDashboard';
// import Model2 from './pages/Models/Model2';
// import Model3 from './pages/Models/Model3';
// import Model4 from './pages/Models/Model4';
// import Model5 from './pages/Models/Model5';
// import Model6 from './pages/Models/Model6';
// import Model7 from './pages/Models/Model7';
// import Model8 from './pages/Models/Model8';
// import Model9 from './pages/Models/Model9';
// import button from './pages/Models/button';
// import cylinder from './pages/Models/cylinder';
// import dataElipse from './pages/Models/dataElipse';
// import ellipse from './pages/Models/ellipse';
// import pipe from './pages/Models/pipe';
// import WorkingAllShapes from './pages/Models/WorkingAllShapes';
// import data from './pages/Models/data';
// import ProcessFlowmodel from './pages/ProcessFlowmodel';
// import Trends from './pages/Trends';
// import LineTrends from './pages/LineTrends';
// import LineGraph from './pages/LineGraph';
// import Historictrends from './pages/HistoricTrends'
// import BarTrends from './pages/BarTrends';
// import AreaTrends from './pages/AreaTrends_old';
// import Events from './pages/Events';
//import Alarms from './pages/Alarms';
// import Model1 from './pages/Models/Model1';
//import HistTrends from './pages/HistTrends_old';
////import Header from './components/Header';
//import datepicker from './pages/datepicker'; 
//import DTms_0010 from './pages/DTms_0010'; 
//import AlarmsEvents from './pages/AlarmsEvents'; 
//import LineChartDemo from './pages/LineChartDemo'; 
//import Report from "./pages/Report"
//import { useSelector,useDispatch } from "react-redux";
//import axios from 'axios';


class App extends React.Component {

   constructor(props) {
        super(props);

        this.state = {
          data:[]
        }
    }


  render(){
    
    if(window.location.pathname ==="/")
    {
      localStorage.clear();
      return(
      
      <div>
        
      <Router>
        {
     
                  
      <Route exact path="/" component={Home} />
    } 
      </Router>
      </div>
      )
    }
    else if (window.location.pathname==="/ForgotPassword"){
      return(
        <div>
          <Router>
            <Route exact path="/ForgotPassword" component={ForgotPassword}/>
            <Route exact path="/" component={Home} />
          </Router>
       
        </div>
      )
      
    }
    else if(window.location.pathname==="/processflow")
   
    {
     
      return(
        <div>
        <Router>
          <Route exact path="/processflow" component={UNCCanvas}/>
        </Router>
      </div>
      )
    }
    else if(window.location.pathname==="/AreaTrends")
    {
      return(
    <div>
    {

sessionStorage.getItem("user")?
<Router >
  <Switch>
  <Route exact path='/AreaTrends' component={Graph}/>
<Route exact path='/HistTrends' component={HistGraph}/>
<Route exact path="/TabularTrends" component={TabularTrends}/>
</Switch>
</Router> 
:  window.location.assign("/") 

}
    </div>
    )
  }
  else if(window.location.pathname==="/HistTrends")
  {
    return(
  <div>
  {

sessionStorage.getItem("user")?
<Router >
<Switch>

<Route exact path='/AreaTrends' component={Graph}/>
<Route exact path='/HistTrends' component={HistGraph}/>
<Route exact path="/TabularTrends" component={TabularTrends}/>

</Switch>
</Router> 
:  window.location.assign("/") 

}
  </div>
  )
}
else if(window.location.pathname==="/TabularTrends")
{
  return(
<div>
{

sessionStorage.getItem("user")?
<Router >
<Switch>

<Route exact path='/AreaTrends' component={Graph}/>
<Route exact path='/HistTrends' component={HistGraph}/>
<Route exact path="/TabularTrends" component={TabularTrends}/>
</Switch>
</Router> 
:  window.location.assign("/") 

}
</div>
)
}
    else
    {
      return(
        <div>
        
  <div>

{
      
      sessionStorage.getItem("user")?
     <Router >
     
       
       <Sidebar/>
      
        <Switch>
        
       <Route exact path="/" component={Home} />
       <Route exact path="/AdminDashboard" component={AdminDashboard}/>
       <Route exact path="/ChangePassword" component={ChangePassword}/>
       <Route exact path="/graph" component={TrendGraph}/>
      <Route exact path="/Report_shift" component={Report_shift}/>
      <Route exact path="/Report_daily" component={Report_daily}/>   
      <Route exact path="/ViewEvents" component={ViewEvents}/>
      <Route exact path="/HistoricEvents" component={HistoricEvents}/>
      <Route exact path="/FileUpload" component={FileUpload}/>
      <Route exact path="/ViewAlarms" component={ViewAlarms}/>
      <Route exact path="/HistoricAlarms" component={HistoricAlarms}/>
      <Route exact path="/Profile" component={Profile}/>
      <Route exact path="/Settings" component={Settings}/>
      {/* <Route exact path="/datepicker" component={datepicker}/>
      <Route exact path="/DTms_0010" component={DTms_0010}/>
      <Route exact path="/AlarmsEvents" component={AlarmsEvents}/> */}
      {/* <Route exact path="/HistTrends1" component={HistTrends}/> */}
      {/* <Route exact path="/Reports" component={Report}/> */}
          {/* //<Route exact path="/LineChartDemo" component={LineChartDemo}/>
      <Route exact path="/Alarms" component={Alarms}/> */}
      {/* <Route exact path="/SupervisorDashboard" component={SupervisorDashboard}/>
       <Route exact path="/EmployeeDashboard" component={EmployeeDashboard}/>
        <Route exact path="/Model1" component={Model1}/>
      <Route exact path="/Model2" component={Model2}/>
      <Route exact path="/Model3" component={Model3}/>
      <Route exact path="/Model4" component={Model4}/>
      <Route exact path="/Model5" component={Model5}/>
      <Route exact path="/Model6" component={Model6}/>
      <Route exact path="/Model7" component={Model7}/>
      <Route exact path="/Model8" component={Model8}/>
      <Route exact path="/Model9" component={Model9}/>
      <Route exact path="/button" component={button}/>
      <Route exact path="/cylinder" component={cylinder}/>
      <Route exact path="/data" component={data}/>
      <Route exact path="/dataElipse" component={dataElipse}/>
      <Route exact path="/ellipse" component={ellipse}/>
      <Route exact path="/pipe" component={pipe}/>
      <Route exact path="/WorkingAllShapes" component={WorkingAllShapes}/>
      <Route exact path="/ProcessFlowmodel" component={ProcessFlowmodel}/>
      <Route exact path="/Trends" component={Trends}/>
      <Route exact path="/LineTrends" component={LineTrends}/>
      <Route exact path="/LineGraph" component={LineGraph}/>
      <Route exact path="/Historictrends" component={Historictrends}/>
      <Route exact path="/BarTrends" component={BarTrends}/>
      <Route exact path="/AreaTrends1" component={AreaTrends}/>
      <Route exact path="/Events" component={Events}/> */}
    

        </Switch>
         
      <Footer/>
      
      </Router> 
         :  window.location.assign("/") 
    
          }
       
    </div>
   
    </div>
 );
      }
}
}
export default App;
