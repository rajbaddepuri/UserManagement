import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

export default class ViewAlarms extends Component {

    constructor(props) {
        super(props);

        this.state = {
          data:[]
        }
    }


    async componentDidMount() {
        try {
            setInterval(async () => {
                axios.get('http://localhost/ScadaClient/api/alarms').then(res => {
//console.log(res);
                    this.setState({ name: res.data });
                   

                });
            }, 1000);

           
            //         });
        } catch (e) {
            //console.log(e);
        }
    }


   
  render() {
        return (
         <h1></h1>  
        )
    }
}