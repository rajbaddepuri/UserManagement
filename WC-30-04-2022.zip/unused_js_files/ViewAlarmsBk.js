import React,{Component} from 'react';
import {Link} from 'react-router-dom';
import axios from 'axios';
import './ViewAlarms.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheckCircle, faWindowClose } from '@fortawesome/fontawesome-free-solid'

import DatePicker from "react-datepicker";    
import "react-datepicker/dist/react-datepicker.css"; 
import DateTimeRangeContainer from 'react-advanced-datetimerange-picker'
import {FormControl} from 'react-bootstrap'
import moment from "moment"
/* import { DateRangePicker } from 'react-dates'; */

import DatetimeRangePicker from 'react-datetime-range-picker';


export default class ViewAlarms extends Component {

    constructor(props){
        super(props);

            this.state = {
                name: [],             
            }
        }


        async componentDidMount() {
            try {
            //   setInterval(async () => {
            //     axios.get('http://localhost/ScadaClient/api/alarms').then(res => {
            //         console.log(res);
            //         this.setState({ name: res.data });
                    
            //     });
            //   }, 0);

            axios.get('http://localhost/ScadaClient/api/alarms').then(res => {
                        console.log(res);
                        this.setState({ name: res.data });
                        
                    });
            } catch(e) {
              console.log(e);
            }
      }
   

    checkValue(param){
      let value = param;
     //   console.log(value);
      if(value == 0.00){
          return "Fault";
      }
      else if(value == 1.00){
          return "Warning";
      }
      else{
          return "Caution";
      }
    }  

    checkAckStatus(param){

     let Ack = param;
      //  console.log(Ack);
      if(Ack == 0){
          return <FontAwesomeIcon icon={faWindowClose}/>
      }
      else if(Ack == 1){
          return <FontAwesomeIcon icon={faCheckCircle}/>
    }
    else{
        return "z";
    }
} 

      
    render(){
    return(
        <body className="font-montserrat">
<div id="main_content">
    <div className="page">    
         
                <div className="section-body">
            
                <div className="row clearfix">
                    <div className="col-xl-12 col-lg-12">
                        <div className="card">
                            <div className="card-header">
                            <ul class="nav nav-tabs page-header-tab">
                            <li class="nav-item"><Link to="/ViewAlarms" class="nav-link active show" data-toggle="tab">View Alarms</Link></li>

                            <li class="nav-item" class="nav-link active show"  href="#Area_Charts"> <a href={'/assets/HistoricAlarms.html'} > Historic Alarms</a></li>
                        
                        </ul>                              
                                {/* <div className="card-options">
                                     <button className="btn btn-sm btn-outline-secondary mr-1" id="one_month">1M</button>
                                    <button className="btn btn-sm btn-outline-secondary mr-1" id="six_months">6M</button>
                                    <button className="btn btn-sm btn-outline-secondary mr-1" id="one_year" class="active">1Y</button>
                                    <button className="btn btn-sm btn-outline-secondary mr-1" id="ytd">YTD</button>
                                    <button className="btn btn-sm btn-outline-secondary" id="all">ALL</button>
                                </div> */}
                            </div>
                         
                        </div>                
                    </div>
              </div> 
              </div>

              <div class="section-body">
                    <div class="container-fluid">
                        <div class="row clearfix">
                            <div class="col-md-12">
                                <div class="tab-content">
                                    <div class="tab-pane active show" id="Company_Settings">
                                        <div class="card">
                                        <div class="card-header">
                                                <h3 class="card-title">Search Alarms</h3>
                                                <div class="card-options">
                                                    <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                                    <a href="#" class="card-options-fullscreen" data-toggle="card-fullscreen"><i class="fe fe-maximize"></i></a>
                                                    <a href="#" class="card-options-remove" data-toggle="card-remove"><i class="fe fe-x"></i></a>
                                                </div>
                                            </div>
                                            <div class="card-body">
                                                <form>
                                                    <div class="row">
                                                    <div className="col-md-3 col-sm-12" style={{marginLeft:"30px"}}>  
                                                Start Date:    <DatePicker className="form-control"    
                                                    selected={this.state.startdate} placeholderText="Start Date" showPopperArrow={false}    
                                                    onChange={this.Changedate}
                                                    />    
                                                    </div>  
                                                    <div className="col-md-3 col-sm-12" style={{marginLeft:"-20px"}}>  
                                                End Date:    <DatePicker className="form-control"    
                                                    selected={this.state.enddate} placeholderText="End Date" showPopperArrow={false}    
                                                    onChange={this.enddate}    
                                                    />    
                                                    </div>  
                                                        <div class="col-md-3 col-sm-12" >
                                                            <div class="form-group" style={{width:"50%", marginTop:"10px" }}>
                                                        
                                                            Device Name:  <input className="form-control" style={{marginLeft:"100px", marginTop:"-25px"}} placeholder="Device Name" type="text" value=""/>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3 col-sm-12">
                                                            <div class="form-group" style={{width:"50%", marginLeft:"1150px", marginTop:"-50px"}}>
                                                             
                                                            Tag Name: <input className="form-control"  style={{marginLeft:"100px", marginTop:"-25px"}} placeholder="Tag Name" type="text" value=""/>
                                                            </div>
                                                        </div>
                                                        </div>
                                                        <div className="col-sm-3 col-sm-12">  
                                                        <button type="submit" className="btn btn-success" style={{marginLeft:"700px"}}>Search</button>  
                                                        </div>  
                                                    
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
              <div className="section-body">
            
                <div className="tab-content">
                    <div className="tab-pane fade show active" id="list" role="tabpanel">
                        <div className="row clearfix">
                            <div className="col-lg-12">
                                <div className="table-responsive" id="users">
                                    <table className="table table-hover table-vcenter text-nowrap table_custom border-style list"> 
                                        <table className="table table-hover table-vcenter mb-0 table_custom spacing8 text-nowrap">
                                        <thead style={{textAlign:"-webkit-center", backgroundColor:"#252d42"}}>
                                            <tr>
                                                <th style={{textTransform:"none", color:"#E5E5E5"}}>Date</th>
                                                <th style={{textTransform:"none", color:"#E5E5E5"}}>Time</th>
                                                <th style={{textTransform:"none", color:"#E5E5E5"}}>Device Name</th>
                                                <th style={{textTransform:"none", color:"#E5E5E5"}}>Tag Name</th>
                                                <th style={{textTransform:"none", color:"#E5E5E5"}}>Description</th>
                                                <th style={{textTransform:"none", color:"#E5E5E5"}}>Alm Value</th>
                                                <th style={{textTransform:"none", color:"#E5E5E5"}}>Ack Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                                           
								     <tr className="" style={{backgroundColor:"black"}}>
                                          
                                         <td className="hidden-xs" >    
                                         
                                     {this.state.name.map((name) => {
                                         var color
                                        if(name.ack == 0 && name.retn == 0){
                                        return <div className="flash" style={{textTransform:"none", color:"#E5E5E5"}}>{name.description.substring(9,21)}</div>
                                         //console.log("black");        
                                        }
                                        else if(name.ack == 0 && name.retn == 1){ 
                                        return <div style={{textTransform:"none", color:"#E5E5E5"}}>{name.description.substring(9,21)}</div>
                                       // console.log(color);
                                        }
                                        else if(name.ack == 1 && name.retn == 0){ 
                                        return <div style={{textTransform:"none", color:"red"}}>{name.description.substring(9,21)}</div>
                                       // console.log("green");
                                        }
                                        else if(name.ack == 1 && name.retn == 1){ 
                                        return <div style={{textTransform:"none", color:"green"}}>{name.description.substring(9,21)}</div>
                                       // console.log("yellow");
                                        }

                                             
                                                   
                                      /*   <ul style={{textAlign:"-webkit-center", marginLeft:"-40px"}} key={name}>{name.DESCRIPTION.substring(9,20)}</ul> */
                                        })}
                                                   {/*  <!--<a href="javascript:void(0);" class="mail-star love"><i class="fa fa-heart"></i> --> */}
                                                </td>


                                        <td className="text-center width40" >
                                               
                                        {this.state.name.map((name) => {
                                         var color
                                        if(name.ack == 0 && name.retn == 0){
                                        return <div className="flash" style={{textTransform:"none", color:"#E5E5E5"}}>{name.description.substring(0,9)}</div>
                                        // console.log("black");        
                                        }
                                        else if(name.ack == 0 && name.retn == 1){ 
                                        return <div style={{textTransform:"none", color:"#E5E5E5"}}>{name.description.substring(0,9)}</div>
                                       // console.log(color);
                                        }
                                        else if(name.ack == 1 && name.retn == 0){ 
                                        return <div style={{textTransform:"none", color:"red"}}>{name.description.substring(0,9)}</div>
                                       // console.log("green");
                                        }
                                        else if(name.ack == 1 && name.retn == 1){ 
                                        return <div style={{textTransform:"none", color:"green"}}>{name.description.substring(0,9)}</div>
                                       // console.log("yellow");
                                        }
                                                   /*  <ul style={{textAlign:"-webkit-center", marginLeft:"-40px"}} key={name}>{name.DESCRIPTION.substring(0,8)}</ul> */
                                                })}
                                                   
                                                       {/* <!-- <img class="avatar" src="../assets/images/xs/avatar3.jpg" alt="avatar"> --> */}
                                                    
                                                </td>
                                        <td className="hidden-xs" > 
                                        {this.state.name.map((name) => {
                                         var color
                                        if(name.ack == 0 && name.retn == 0){
                                        return <div className="flash" style={{textTransform:"none", color:"#E5E5E5"}}>{name.devicename}</div>
                                       //  console.log("black");        
                                        }
                                        else if(name.ack == 0 && name.retn == 1){ 
                                        return <div style={{textTransform:"none", color:"#E5E5E5"}}>{name.devicename}</div>
                                       // console.log(color);
                                        }
                                        else if(name.ack == 1 && name.retn == 0){ 
                                        return <div style={{textTransform:"none", color:"red"}}>{name.devicename}</div>
                                       // console.log("green");
                                        }
                                        else if(name.ack == 1 && name.retn == 1){ 
                                        return <div style={{textTransform:"none", color:"green"}}>{name.devicename}</div>
                                       // console.log("yellow");
                                        }                                          
                                             
                                              /*   <ul style={{textAlign:"-webkit-center", marginLeft:"-40px"}} key={name}>{name.DEVICENAME}</ul> */
                                                })}
                                                </td> 
                                              
                                                
                                                <td className="hidden-xs" >
                                                  {/*  <!-- <div class="text-muted">maryadams@info.com</div>--> */}
                                                
                                            
                                        {this.state.name.map((name) => {
                                         var color
                                        if(name.ack == 0 && name.retn == 0){
                                        return <div className="flash" style={{textTransform:"none", color:"#E5E5E5"}}>{name.pointname}</div>
                                        // console.log("black");        
                                        }
                                        else if(name.ack == 0 && name.retn == 1){ 
                                        return <div style={{textTransform:"none", color:"#E5E5E5"}}>{name.pointname}</div>
                                       // console.log(color);
                                        }
                                        else if(name.ack == 1 && name.retn == 0){ 
                                        return <div style={{textTransform:"none", color:"red"}}>{name.pointname}</div>
                                       // console.log("green");
                                        }
                                        else if(name.ack == 1 && name.retn == 1){ 
                                        return <div style={{textTransform:"none", color:"green"}}>{name.pointname}</div>
                                       // console.log("yellow");
                                        }
                                               /*  <ul style={{textAlign:"-webkit-center", marginLeft:"-40px"}} key={name}>{name.POINTNAME}</ul> */
                                                  })}
                                                </td>
                                                
										<td className="hidden-xs" >

                                        {this.state.name.map((name) => {
                                         var color
                                        if(name.ack == 0 && name.retn == 0){
                                        return <div className="flash" style={{textTransform:"none", color:"#E5E5E5"}}>{name.description.substring(33,100)}</div>
                                       //  console.log("black");        
                                        }
                                        else if(name.ack == 0 && name.retn == 1){ 
                                        return <div style={{textTransform:"none", color:"#E5E5E5"}}>{name.description.substring(33,100)}</div>
                                       // console.log(color);
                                        }
                                        else if(name.ack == 1 && name.retn == 0){ 
                                        return <div style={{textTransform:"none", color:"red"}}>{name.description.substring(33,100)}</div>
                                      //  console.log("green");
                                        }
                                        else if(name.ack == 1 && name.retn == 1){ 
                                        return <div style={{textTransform:"none", color:"green"}}>{name.description.substring(33,100)}</div>
                                       // console.log("yellow");
                                        }
                                             /*    <ul style={{textAlign:"-webkit-center", marginLeft:"-40px"}} key={name}>{name.DESCRIPTION.substring(33,77)}</ul> */
                                                })}

                                                </td>

                                        <td class="hidden-xs" >

                                        {this.state.name.map((name) => {
                                         var color
                                        if(name.ack == 0 && name.retn == 0){
                                
                                        return <div className="flash" style={{textTransform:"none", color:"#E5E5E5"}}>{this.checkValue(name.value)}</div>
                                       //  console.log("black");        
                                        }
                                        else if(name.ack == 0 && name.retn == 1){ 
                                        return <div style={{textTransform:"none", color:"#E5E5E5"}}>{this.checkValue(name.value)}</div>
                                       // console.log(color);
                                        }
                                        else if(name.ack == 1 && name.retn == 0){ 
                                        return <div style={{textTransform:"none", color:"red"}}>{this.checkValue(name.value)}</div>
                                       // console.log("green");
                                        }
                                        else if(name.ack == 1 && name.retn == 1){ 
                                        return <div style={{textTransform:"none", color:"green"}}>{this.checkValue(name.value)}</div>
                                       // console.log("yellow");
                                        }
                                                 /*    <ul style={{textAlign:"-webkit-center", marginLeft:"-40px"}} key={name}>{name.VALUE}</ul>  */
                                                })}
                                                            
                                                </td>

                                                <td className="hidden-xs" >

                                        {this.state.name.map((name) => {
                                         var color
                                        if(name.ack == 0 && name.retn == 0){
                                        return <div className="flash" style={{textTransform:"none", color:"#E5E5E5"}}>{this.checkAckStatus(name.ack)}</div>
                                        // console.log("black");        
                                        }
                                        else if(name.ack == 0 && name.retn == 1){ 
                                        return <div style={{textTransform:"none", color:"#E5E5E5"}}>{this.checkAckStatus(name.ack)}</div>
                                        //console.log(color);
                                        }
                                        else if(name.ack == 1 && name.retn == 0){ 
                                        return <div style={{textTransform:"none", color:"red"}}>{this.checkAckStatus(name.ack)}</div>
                                        //console.log("green");
                                        }
                                        else if(name.ack == 1 && name.retn == 1){ 
                                        return <div style={{textTransform:"none", color:"green"}}>{this.checkAckStatus(name.ack)}</div>
                                        //console.log("yellow");
                                        }
                                               /*  <ul style={{textAlign:"-webkit-center", marginLeft:"-40px"}} key={name}>{name.ACK}</ul> */
                                                })}
                                                   
                                                </td>
												
                                            </tr>
                                 
                                    
                                            </tbody>
                                    </table>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                    </div>
          </div>
          </div> 
          
</body>
    )
    }
    }