import React,{Component} from 'react';
import {Link} from 'react-router-dom';
import DatePicker from "react-datepicker";    
import "react-datepicker/dist/react-datepicker.css"; 
import LineGraph from 'react-line-graph';

import Select from 'react-select';

//import 'chartjs-plugin-crosshair';

import axios from 'axios'; 

//import 'chartjs-plugin-zoom';

/* import './AreaGraph'; */

import { Line } from 'react-chartjs-2'; 

import Chart from "react-google-charts"; 
import { chart, Color } from 'highcharts';
import { faXRay } from '@fortawesome/fontawesome-free-solid';
import IP from './Utiltys';


export default class HistoricTrends extends Component{
    
    constructor(props) {  

        super(props);  

        this.state = { 
            Data: [],
            name: [],
            charts: [],
        
            Date: [],
            selectedOption: '',
            clearable: true,
            currentDateTime: new Date().toLocaleString()
           
        };
        
/* 
         currentDateTime: new Date(); */
} 

async componentDidMount() {
    try {
      setInterval(async () => {
        axios.get('http://'+IP+'/ScadaClient/api/GroupName?GroupName=').then(res => {
            console.log(res);
            this.setState({ name: res.data });
            
        });
      }, 50);
    } catch(e) {
      console.log(e);
    } 

 /*    try {
      setInterval(async () => {
        axios.get('http://'+IP+'/ScadaClient/api/trendsdata?PointName=DTms_0017').then(res => {
            console.log(res);
            this.setState({ Date: res.data });
            const Date = res.data;
            console.log(Date);
            let timeStampTime = [];
            Date.forEach(record => { 

              timeStampTime.push(record.timeStampTime);
              console.log(timeStampTime);


          });  

            
        });
      }, 50);
    } catch(e) {
      console.log(e);
    } */
  }

  async apiCall() {
    setInterval(async () => {
    axios.get('http://'+IP+'/ScadaClient/api/GroupwithTrendsTimestamp?GroupName=sample')  

    .then(res => {  

            console.log(res);
            this.setState({charts: res.data});

            const charts = res.data;
            console.log(charts);


             /*  const chart1 = chart[0]
             console.log(chart1); 

             this.setState({chart1: chart[0]});
             console.log(chart1);  */
             
            /* let Date = newDate();  */

            /* let currentDateTime = Date().toLocaleString() */


            let Data = [];

            let fvalue = []; 
            
            let timeStampTime = [];

           /*  this.state.chart.map((user, index) => (
               eventKey={index}>user.fvalue
            ));

            console.log(fvalue); */

            var record0 =  this.state.charts[0];
            console.log(record0); 

            var record1 =  this.state.charts[1];
            console.log(record1);

              this.state.charts.map((record) => { 
                fvalue.push(record.fvalue);

                timeStampTime.push(record.timeStampTime);  

            });  console.log(fvalue); 
           
/* 
            this.setState({
               options : {
              responsive: true,
              crosshair: {
                line: {
                  color: '#F66',  // crosshair line color
                  width: 1        // crosshair line width
                },
                sync: {
                  enabled: true,            // enable trace line syncing with other charts
                  group: 1,                 // chart group
                  suppressTooltips: false   // suppress tooltips when showing a synced tracer
                },
                zoom: {
                  enabled: true,                                      // enable zooming
                  zoomboxBackgroundColor: 'rgba(66,133,244,0.2)',     // background color of zoom box 
                  zoomboxBorderColor: '#48F',                         // border color of zoom box
                  zoomButtonText: 'Reset Zoom',                       // reset zoom button text
                  zoomButtonClass: 'reset-zoom',                      // reset zoom button class
                },
                callbacks: {
                  beforeZoom: function(start, end) {                  // called before zoom, return false to prevent zoom
                    return true;
                  },
                  afterZoom: function(start, end) {                   // called after zoom
                  }
                }
              },
      
              labels: timeStampTime, 
          
            
                       datasets: [
      
                            {  
                                    text: 'F Value',
      
                                    type: 'line',
                                   
                                    label: 'F Value', 
      
                                    data: fvalue,
      
                                    fill: true,
      
                                     backgroundColor: "rgba(75,192,192,0.2)",
                                    borderWidth: 5,
                                    borderColor: "rgba(75,192,192,1)",
                                    pointBorderColor: "rgba(75,192,192,1)",
                                    pointBackgroundColor: "rgba(75,192,192,0.2)",
                                    pointBorderWidth: 5,
                                    pointHoverRadius: 10,
                                    pointHoverBackgroundColor: "rgba(75,192,192,0.2)",
                                    pointHoverBorderColor: "rgba(75,192,192,1)",
                                    pointHoverBorderWidth: 15, 
      
      
      
                            } ,
                 
      
                          ]
        }
      }) */

        /*     for (let x = 0; x <= 10; x++) {
              const random = Math.random();
              const temp = chart.length > 0 ? chart[chart.length-1].y : 50;
              const y = random >= .45 ? temp + Math.floor(random * 20) : temp - Math.floor(random * 20);
              Data.push({x,y})
              console.log(Data)
            } */

         /*    sorted.forEach(record => {
                
                timeStampTime.push(record.timeStampTime);   
            }) */
      

    }) 
    
    
}, 50);
}


updateChart() {
  yVal = yVal +  Math.round(5 + Math.random() *(-5-5));
  dps.push({x: xVal,y: yVal});
  xVal++;
  if (dps.length >  10 ) {
    dps.shift();
  }
    this.chart.render();  
}

 handleDropDown = event => {
    this.setState(
      {
        [event.target.name]: event.target.value,     
      }, 
    );  
  }; 

   onClickHandler = event => {
    const dropdown1 = event.target.name;
    this.setState({ dropdown1 })
    console.log(dropdown1);
  }
  
  handleChange = selectedOption => {
    this.setState({ selectedOption });
    console.log(`Option selected:`, selectedOption);
  };

   apiCall() {
    {this.state.charts.map(chart => (
      <option  value={chart}>
        {chart.POINTNAME}
      </option>
    ))} 
  } 

  handleApi() {
    chart.forEach(record => {  

      fvalue.push(record.fvalue);

      timeStampTime.push(record.timeStampTime);  

  }); 
  }

renderList() {
    return (this.state.name.map(name => (
        <option value={name}>
          {name.CURTRENDTITLE} 
        </option>
      )))
   }

    render(){
  /*     const data = {
      
          
                }
               */
    return(
        <body className="font-montserrat">
{/* <!-- Page Loader --> */}
{/* <div className="page-loader-wrapper">
    <div className="loader">
    </div>
</div> */}

<div id="main_content">

    <div className="page">
    <div className="section-body">
            <div className="container-fluid">
                <div className="row clearfix">
                    <div className="col-lg-12">
                        <div className="d-lg-flex justify-content-between">
                            <ul className="nav nav-tabs page-header-tab">
                                <li className="nav-item"><Link to="/AreaTrends" className="nav-link active show" data-toggle="tab" href="#Area_Charts">Trends</Link></li>

                                <li className="nav-item"><Link to="/HistoricTrends" className="nav-link" data-toggle="tab" href="#Email_Settings">Historic Trends</Link></li>
                                
                                <li className="nav-item"><Link to="/TabularTrends" className="nav-link" data-toggle="tab" href="#Change_Password">Tabular Trends </Link></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
 
       
        <div className="section-body">
                <div className="container-fluid">
                <div className="row clearfix">
                    <div className="col-xl-12 col-lg-12">
                        <div className="card">
                            <div className="card-header">
                                <h3 className="card-title">Historic Trends</h3>
                                <div className="card-options">
                                    
                                {/* <div className="dropdown" style={{marginRight:"34px"}}>
                                    <button className="custom-select" id="dropbtn">Last 2 Hours</button>
                                    <div className="dropdown-content">
                                       
                                        <Link to="">Last 1 Hour</Link>
                                        <Link to="">Last 30 Minutes</Link>
                                        <Link to="">Last 10 Minutes</Link>                                     
                                       
                                    </div>
                                </div> */}
								
        <div className="dropdown" style={{marginRight:"34px"}}> 

        <section className="wrapper">
        <div className="wrapper_inner"> 
        {/*   <h2 className="title">Currency Converter</h2> */}

           <div className="flex">
            <form className="flex-column"> 
              {/* <div className="custom-select"> */}
              <select
                className="custom-select"
                value={this.selectedOption}
                 onChange={this.handleChange}
                 onClick={this.apiCall()}
                 
              >
                {this.state.name.map(name => (
                  <option  value={name}>
                    {name.CURTRENDTITLE}
                  </option>
                ))}
                
              </select>  
            {/*   <Select
           
                value={this.state.value}
                onChange={this.handleChange}
                clearable={this.state.clearable}
                searchable={this.state.searchab}
                options={this.renderList()} 
              /> */}

            
              {/* </div> */}
             {/*  <input
                className="result_input"
                type="number"
                value={amount}
                onChange={this.handleInput}
              /> */}
            </form>
            </div>
            </div>
            </section> 
  
                      </div>
                                    <div className="dropdown" style={{marginRight:"34px"}}>
                                    <button className="custom-select" id="dropbtn">Trends in Area</button>
                                    <div className="dropdown-content">
                                       
                                        <Link to="/LineTrends">Trends in Line</Link>
                                        <Link to="/BarTrends">Trends in Bar</Link>                                     
                                       
                                    </div>
                                </div>
					
			
                                    <button className="btn btn-sm btn-outline-secondary mr-1" id="one_month">1M</button>
                                    <button className="btn btn-sm btn-outline-secondary mr-1" id="six_months">6M</button>
                                    <button className="btn btn-sm btn-outline-secondary mr-1" id="one_year" className="active">1Y</button>
                                    <button className="btn btn-sm btn-outline-secondary mr-1" id="ytd">YTD</button>
                                    <button className="btn btn-sm btn-outline-secondary" id="all">ALL</button>
                                </div>
                            </div>
                            
                        </div>                
                    </div>
                    
              </div>  
              </div>
</div>
         
<div className="section-body">
         <div className="tab-content" style={{marginBottom:"300px"}}>
                <div className="tab-pane fade show active" id="list" role="tabpanel">
                <div className="col-lg-12">
                
               <div className="row clearfix"> 
               
               <Line height={'300px'} width={'1000px'} data = {
                 {
                   type: 'spline',
                   labels: [
                     //timeStampTime
                   ],  
                  /* data: timeStampTime,  */
                
                            datasets: [
           
                                {  
                                  text: 'F Value',
           
                                        type: 'line',
                                       
                                        label: 'F Value', 
           
                                        data: fvalue, 
           
                                        fill: true,
           
                                         backgroundColor: "rgba(75,192,192,0.2)",
                                        borderWidth: 5,
                                        borderColor: "rgba(75,192,192,1)",
                                        pointBorderColor: "rgba(75,192,192,1)",
                                        pointBackgroundColor: "rgba(75,192,192,0.2)",
                                        pointBorderWidth: 5,
                                        pointHoverRadius: 10,
                                        pointHoverBackgroundColor: "rgba(75,192,192,0.2)",
                                        pointHoverBorderColor: "rgba(75,192,192,1)",
                                        pointHoverBorderWidth: 15, 
           
                                } ,
                              
                              ] 
                            }

                            
               }
              
               /*  options={{
                        options : {
                          responsive: true,
                          crosshair: {
                            line: {
                              color: '#F66',  // crosshair line color
                              width: 1        // crosshair line width
                            },
                            sync: {
                              enabled: true,            // enable trace line syncing with other charts
                              group: 1,                 // chart group
                              suppressTooltips: false   // suppress tooltips when showing a synced tracer
                            },
                            zoom: {
                              enabled: true,                                      // enable zooming
                              zoomboxBackgroundColor: 'rgba(66,133,244,0.2)',     // background color of zoom box 
                              zoomboxBorderColor: '#48F',                         // border color of zoom box
                              zoomButtonText: 'Reset Zoom',                       // reset zoom button text
                              zoomButtonClass: 'reset-zoom',                      // reset zoom button class
                            },
                            callbacks: {
                              beforeZoom: function(start, end) {                  // called before zoom, return false to prevent zoom
                                return true;
                              },
                              afterZoom: function(start, end) {                   // called after zoom
                              }
                            }
                          },
                                            
                    }
               }} */
                 options={{
                    responsive: true,
                    title: { text: "Trends", display: true },
                    scales: {
                      yAxes: [
                        {
                          ticks: {
                            autoSkip: true,
                            maxTicksLimit: 10,
                            beginAtZero: true,
                          },
                          gridLines: {
                            display: true,
                          },
                        },
                      ],
                      xAxes: [
                        {
                          gridLines: {
                            display: true,
                          },
                        },
                      ],
                    },
                    pan: {
                      enabled: true,
                      drag: false,
                      mode: "xy",
                      speed: 10,
                      threshold: 10,
                    },
                    zoom: {
                      enabled: true,
                      drag: false,
                      mode: "xy",
                      limits: {
                        max: 1,
                        min: 0.5,
                      },
                      rangeMin: {
                        x: 2,
                        y: 1,
                      },
                      rangeMax: {
                        x: 10,
                        y: 150,
                      },
                    },
                    tooltips: {
                      mode: 'interpolate',
                      intersect: false
                    },
                    plugins: {
                      crosshair: {
                        line: {
                          color: '#F66',  // crosshair line color
                          width: 1        // crosshair line width
                        },
                        sync: {
                          enabled: true,            // enable trace line syncing with other charts
                                          // chart group
                          suppressTooltips: false   // suppress tooltips when showing a synced tracer
                        },
                        zoom: {
                          enabled: true,                                      // enable zooming
                          zoomboxBackgroundColor: 'rgba(66,133,244,0.2)',     // background color of zoom box 
                          zoomboxBorderColor: '#48F',                         // border color of zoom box
                          zoomButtonText: 'Reset Zoom',                       // reset zoom button text
                          zoomButtonClass: 'reset-zoom',                      // reset zoom button class
                        },
                        callbacks: {
                          beforeZoom: function(start, end) {                  // called before zoom, return false to prevent zoom
                            return true;
                          },
                          afterZoom: function(start, end) {                   // called after zoom
                          }
                        }
                      }
                      }
                  }} 
               />  
               </div> 
               </div>

               <div className="section-body">
                <div className="container-fluid">
                <div className="row clearfix">
                    <div className="col-xl-12 col-lg-12">
                    <div className="row" style={{marginTop:"20px"}}>
                    
                    Sample Rate : <div className="col-md-4 col-sm-4" className="dropdown"  style={{marginRight:"50px", marginTop:"-7px"}}>
                                             <button className="custom-select" id="dropbtn">15 seconds</button>
                                             <div className="dropdown-content">
                                                 <Link to =''>30 seconds</Link>
                                                 <Link to="">1 min</Link>
                                                 <Link to="">5 min</Link>
                                                 <Link to="">15 min</Link>
                                                 <Link to="">30 min</Link>
                                                 <Link to="">1 hour</Link>
                                                 <Link to="">2 hour</Link>
                                     
                                                
                                             </div><br/>
                      
                                         </div>
                                         <div className="col-md-4 col-sm-4" style={{marginLeft:"100px"}}>   
                                    
                     <label>
                      Marker Time : <input style={{width:"400px"}} type="text" name="name" />
                     </label>
                       
                   </div>
                                     
                   <div className="col-md-4 col-sm-4" style={{marginLeft:"145px"}}>
                   Window Span(min) : <div className="dropdown"  >
                                             <button className="custom-select" id="dropbtn">5 min</button>
                                             <div className="dropdown-content">
                                             <Link to="">15 min</Link>
                                                 <Link to="">30 min</Link>
                                                 <Link to="">1 hour</Link>
                                                 <Link to="">2 hour</Link>
                   </div></div></div></div>      
                    </div>
                    
              </div>  
              </div>
</div>

<div className="section-body">
        
        <div className="row clearfix">
            <div className="col-md-12">
            <div className="row">  
            </div>  
            <form onSubmit={this.onsubmit}>  
                <div className="row hdr" style={{marginTop:"20px"}}>  
                   { <div className="col-sm-4 col-md-4 form-group">  </div> } 
                    <div className="col-sm-3 form-group" style={{marginLeft:"-505px", width:"65%"}}>  
                    Start Date:        <DatePicker className="form-control"    
                                                    selected={this.state.startdate} placeholderText="Start Date" showPopperArrow={false}    
                                                    onChange={this.Changedate}    
                                            />    
                    </div>  
                    <div className="col-sm-4 col-md-4 form-group" style={{marginLeft:"-25px", width:"65%"}}>  
                    End Date:         <DatePicker className="form-control"    
                                                    selected={this.state.enddate} placeholderText="End Date" showPopperArrow={false}    
                                                    onChange={this.enddate}    
                                            />    
                    </div>  
                    <div className="col-sm-4 col-md-4 form-group" style={{marginLeft:"-150px"}}>  
                        <button type="submit" className="btn btn-success">Get History Data</button>  
                    </div>  
                </div>
              
            </form>
            </div>
            </div>
            </div>
      {/*   <div className="areaChart" style={{marginLeft:"-130px", marginTop:"-10px"}}>
        <Chart
   width={'1100px'}
  height={'850px'}
  chartType="AreaChart"
  loader={<div>Loading Chart</div>}
  data={[
    ['Year', 'Sales', 'Expenses'],
    ['2012', 900, 500],
    ['2013', 1000, 400],
    ['2014', 1170, 460],
    ['2015', 660, 1120],
    ['2016', 1030, 540],
    ['2017', 1000, 600],
    ['2018', 1170, 560],
    ['2019', 660, 1020],
    ['2020', 1030, 740],
  ]}
  options={{
    isStacked: true,
    height: 600,
    legend: { position: 'top', maxLines: 6 },
    vAxis: { minValue: 0 },
  }}
  rootProps={{ 'data-testid': '2' }}
/></div> */}
</div></div></div>

<div className="section-body">
            
            <div className="tab-content">
                <div className="tab-pane fade show active" id="list" role="tabpanel">
                    <div className="row clearfix" style={{marginTop:"-300px"}}>
                        <div className="col-lg-12">
                            <div className="table-responsive"  id="users">
                                <table className="table table-hover table-vcenter text-nowrap table_custom border-style list"> 
                                    <table className="table table-hover table-vcenter mb-0 table_custom spacing8 text-nowrap">
                                    <thead style={{textAlign:"-webkit-center", backgroundColor:"#252d42"}}>
                                        <tr>
                                            <th style={{textTransform:"none", color:"#E5E5E5"}}>Tag Name</th>
                                            <th style={{textTransform:"none", color:"#E5E5E5"}}>High Limit</th>
                                            <th style={{textTransform:"none", color:"#E5E5E5"}}>Low Limit</th>
                                            <th style={{textTransform:"none", color:"#E5E5E5"}}>Marker Value</th>
                                        </tr>
                                    </thead>
                                   <tbody>
                                        
                                            <tr className="">
                                            <td className="hidden-xs" style={{color:"green"}}>
                                            
                                             {this.state.charts.map(charts => (
                                            <ul style={{textAlign:"-webkit-center", marginLeft:"-40px"}} >{this.apiCall(charts.POINTNAME)}</ul>
                                            ))} 
                                           
                                            
                                               {/*  <!--<a href="javascript:void(0);" className="mail-star love"><i className="fa fa-heart"></i> --> */}
                                            </td>
                                            <td className="hidden-xs" style={{color:"green"}}>
                                            
                                            {this.state.charts.map(charts => (
                                            <ul style={{textAlign:"-webkit-center", marginLeft:"-40px"}}>{charts.UPPERVALUE}</ul>
                                            ))}
                                           
                                            
                                               {/*  <!--<a href="javascript:void(0);" className="mail-star love"><i className="fa fa-heart"></i> --> */}
                                            </td>
                                            <td className="text-center width40" style={{color:"green"}}>
                                                {/* <!--<div className="avatar d-block">--> */}
                                            
                                                {this.state.charts.map(charts => (
                                            <ul style={{textAlign:"-webkit-center", marginLeft:"-40px"}} >{charts.LOWERVALUE}</ul>
                                            ))}
                                               
                                                   {/* <!-- <img className="avatar" src="../assets/images/xs/avatar3.jpg" alt="avatar"> --> */}
                                                
                                            </td>
                                            <td className="hidden-xs" style={{color:"green"}}>                                               
                                            {this.state.charts.map(charts => (
                                            <ul style={{textAlign:"-webkit-center", marginLeft:"-40px"}} >{charts.PENCOLOR}</ul>
                                            ))}
                                            </td> 
                           
                                            
                                        </tr>
                                        </tbody>
                                </table>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                </div>
                    
                    </div>
        </div>
                  
              
</body>
    )
}
}
