import axios from 'axios';
import React,{Component} from 'react';

export const GraphData = [


  
    

    { "dx": "0", "dy": "0", "grid": null, "gridSize": null, "guides": null, "tooltips": null, "connect": null, "arrows": null, "fold": null, "page": null, "pageScale": null, "pageWidth": "800", "pageHeight": "600", "root": [{ "id": "1", "parent": "0", "value": "", "style": "shape=rectangle;margin-left256px;top=0px;right=500px;bottom=83px;left=0px;zindex=1px;margin-top161px;gradientColor=#aaffff;gradientDirection=east;", "vertex": "1", "mxGeometry": { "x": "300", "y": "90", "width": "85", "height": "100", "_as": null, "relative": null, "mxPoint": null, "Array": null }, "edge": null },
     { "id": "2", "parent": "0", "value": "", "style": "shape=line;color=#000000", "vertex": "1", "mxGeometry": { "x": "600", "y": "120", "width": "165", "height": "80", "_as": null, "relative": null, "mxPoint": null, "Array": null }, "edge": null }] }

];

export default GraphData;