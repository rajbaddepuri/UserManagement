export const GraphData = [

    {
        "dx": "0",
        "dy": "0",
        "grid": null,
        "gridSize": null,
        "guides": null,
        "tooltips": null,
        "connect": null,
        "arrows": null,
        "fold": null,
        "page": null,
        "pageScale": null,
        "pageWidth": "800",
        "pageHeight": "600",
        "root": [{
            "id": "1",
            "parent": "0",
            "value": "SHAPE_10014",
            "style": "shape=ellipse;margin-left256px;top=0px;right=500px;bottom=83px;left=0px;zindex=1px;margin-top161px;gradientColor=#aaffff;gradientDirection=east;",
            "vertex": "1",
            "mxGeometry": { "x": "450", "y": "120", "width": "105", "height": "80", "_as": null, "relative": null, "mxPoint": null, "Array": null },
            "edge": null
        }]
    }

];

export default GraphData;