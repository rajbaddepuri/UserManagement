import React,{Component} from 'react';

class ProfileDetails extends Component {
 
  render(){
    return(
          <h1>hi</h1>
      );
  }
}
export default ProfileDetails;