

import express from 'express';
import cron from 'node-cron'
import bodyParser from 'body-parser'
import cors from 'cors'
import sql from 'mssql'
import * as fs from 'fs';
//import * as fs from 'graceful-fs';
import * as path from 'path';
import moment from 'moment';
import { } from 'dotenv/config'







var app = express();
var router = express.Router();


app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
app.use('/api', router);


router.use((request, response, next) => {
  //console.log('middleware');
  next();
})

app.get("/", (req, res) => {
  res.json({ message: "Welcome to ECSCADA application." });
});


const config = {
  user: 'sa',
  password: 'scada123',
  server: 'localhost',
  database: 'ECDBAZE',
  options: {
    //         trustedconnection: true,
    enableArithAbort: false,
    //         instancename :'SQLEXPRESS'
  },
  port: 1433

  //  user: 'sa',
  //  password: 'scada123',
  //  server: 'localhost', 
  //  database: 'ECDBAZE',
  //  synchronize: true,
  //  trustServerCertificate: true,
}


/// ...............Web REports For Mobile..............///

//.............. for creating folader inside the project..........///


cron.schedule("* */10 * * * *", function () {

  console.log("rajkumar..enterd")

  async function gettrendvalues() {
    // var fs = require("fs")
    let pool = await sql.connect(config);
    //console.log(pool)
    let Tagname1 = await pool.request().query("SELECT distinct pointname from currentgroup")
   // console.log(Tagname1.recordsets)
    const Tagname = []
    Tagname1.recordsets.map((a => {
      Tagname.push(a)
    }))
    ////console.log(Tagname[0])
    // //console.log(Tagname[0])
    // var filePath = "E:/unical/DynamicFlatFiles/OutputFolder/"
    var filePath = process.env.Logfile_Path;
    // fs.writeFile('data.text', JSON.stringify(fileData), (err) => {
    //     // In case of a error throw err.
    //     if (err) throw err;
    // })
    //var fs = require('fs');
    // const moment = require('moment');
    var time = moment(new Date()).format("YYYY-MM-DD HHmmss").toString()
    //moment(s.DateofJoining).format('MM/DD/YYYY');
    " DTms_0010$2022-01-07 154105.108000000"
    // //console.log("2022-01-07 154105")
    // //console.log(time)
    try {
      for (let i = 0; i < Tagname[0].length; i++) {
        //let products = await pool.request().query(`select slno,plntloc,pointname,fvalue,timestamp,Quality from webdata_log where pointname ='${Tagname[0][i].pointname}'`);
        let products = await pool.request().query(`select fvalue,timestamp,Quality from webdata_log where pointname ='${Tagname[0][i].pointname}' order by timestamp`);
        // //console.log("finding the length of the ")
        var temp = products.recordsets
        // //console.log(temp)
        let fileData = []
        temp.map((a) => {
          fileData.push(a)
        })
        //console.log(fileData[0].length)
        var mydata = []
        fileData[0].map((a) => {
          ////console.log( moment (new Date ("2022-02-09 14:50:47")).format("YYYY-MM-DD HH:MM:SS"));
          let s = a.timestamp;
          let d = new Date(Date.parse(s));
          //  //console.log(d.toString());
          var date = new Date(a.timestamp);
          var seconds = date.getTime() / 1000; //1440516958
          //console.log(seconds)
          var secto = 19800;
          var time = (new Date((seconds - secto) * 1000)).toString()
          //console.log(time)
          // mydata.push(a.slno,a.plntloc,a.pointname,a.fvalue,moment (a.timestamp).format("YYYY-MM-DD HH:mm:ss"),a.Quality,"}","\n");
          mydata.push(a.fvalue, moment(time).format("YYYY-MM-DD HH:mm:ss"), a.Quality, "}", "\n");
        })
        // //console.log(mydata)
        var mydata1 = mydata.toString();
        //   //console.log("2nd con",mydata1)
        var mydata2 = mydata1.split("},");
        var mydata3 = mydata2.toString();
        var mydata4 = mydata3.replace(",}", " ");
        if (mydata4.length > 0) {
           // console.log("mydata length"+Tagname[0][i].pointname,mydata4.length )
            var current_date =  moment(new Date()).format("YYYY-MM-DD")
            var createStream = fs.createWriteStream(filePath + Tagname[0][i].pointname + '$' + current_date + '.txt', {
              flags: 'a' // 'a' means appending (old data will be preserved)
            })
            var writeLine = (line) => createStream.write(`\n${line}`);
            writeLine(mydata4);
            createStream.end();
        }
          
        // var Delete = `delete from webdata_log where pointname ='${Tagname[0][i].pointname}'`
        // //console.log("the delet query",Delete)
        // await pool.request().query(Delete);
      }
    }
    catch {
      console.log(err);
      // Close the file descriptor
    }
    //finally{
    //}
    let Delete = await pool.request().query("Delete from webdata_log");
     
    return Tagname1.recordsets;
  }

  gettrendvalues();
});

//////////.........to get the historic trend data ............///
app.post('/historicdata', function (req, res) {

  // console.log("rajkumar")
  let response = req.body
  console.log(req.body)

  var fromDate = response['fromDate'];
  var toDate = response['toDate'];
  var selctedGroup = response['selctedGroup'];
  //   var fromDate = "2022-05-07T11:42:53";
  //   var toDate = "2022-05-07T13:47:53";
  //   var selctedGroup = "DAS_GRP2";
  var selctedGroupTags = [];

  //Betwean Dates of From Date and To Date---
  function getDates(startDate, endDate) {
    const dates = []
    let currentDate = startDate
    const addDays = function (days) {
      const date = new Date(this.valueOf())
      date.setDate(date.getDate() + days)
      return date
    }
    while (currentDate <= endDate) {
      dates.push(currentDate)
      currentDate = addDays.call(currentDate, 1)
    }
    return dates
  }
  //Calling betwean Dates Function----
  const dates = getDates(new Date(fromDate), new Date(toDate))
  //Directory Files Path----
  //const directoryPath = "E:/unical/DynamicFlatFiles/OutputFolder/";
  const directoryPath = process.env.Logfile_Path;
  //Reading Directory Files
  fs.readdir(directoryPath, function (err, files) {
    if (err) {
      res.status(500).send({
        message: "Unable to scan files!",
      });
    }

    //1-- get all tags in that group
    //Call Api or connect to Db
    //console.log(order["InputScript"])
    sql.connect(config, function (err) {
      // create Request object
      var request = new sql.Request();
      //let quer2 = "SELECT POINTNAME FROM currentgroup WHERE CURTRENDTITLE='DAS_GRP2'";
      let quer2 = `SELECT POINTNAME FROM currentgroup WHERE CURTRENDTITLE ='${selctedGroup}'`;
      request.query(quer2, function (err, recordset) {
        selctedGroupTags = recordset.recordset;
        //console.log("raj1",selctedGroupTags)
        var Filename = {}
        //TAGS LOOP
        var tagwisedata = [];
        for (var i = 0; i < selctedGroupTags.length; i++) {
          for (var j = 0; j < dates.length; j++) {
            //console.log(selctedGroupTags[i]['POINTNAME']+"$"+moment(dates[j]).format('YYYY-MM-DD'))
            files.findIndex(checkfilename);
            function checkfilename(file) {
              if (file.includes(selctedGroupTags[i]['POINTNAME'] + "$" + moment(dates[j]).format('YYYY-MM-DD'))) {
                //  console.log("result",file)
                ///---read file ----//
                ///---push to tagwaise data  at index--------//
                //  console.log("path",directoryPath+file)
                try {
                  var data = fs.readFileSync(directoryPath + file, 'utf8');
                  // console.log(data.length);  
                  // console.log("rajkumar123",data.length) 
                  data = "," + data;
                  data = data.replace("\n", "")
                  var tagData = data.toString().split(",,");
                  // console.log("Length of tags"+tagData.length)
                  //console.log(tagData);

                  for (let k = 0; k < tagData.length - 1; k++) {
                    var tagSplit = tagData[k].split(",");
                    // console.log("Splitbycama"+tagSplit.toString())
                    // console.log(tagSplit)
                    //Filtering based on DateTime ----
                    if (moment(tagSplit[2]).isAfter(moment(fromDate)) && moment(tagSplit[2]).isBefore(moment(toDate))) {
                      // {"slno":null,"pointname":"DTms_0010","fvalue":"1","timestamp":"2022-05-07 13:05:48","plntloc":null,"Quality":"3"},
                      tagwisedata.push({
                        "slno": null,

                        "pointname": selctedGroupTags[i]['POINTNAME'],
                        "fvalue": tagSplit[1] ?? "",
                        "timestamp": tagSplit[2] ?? "",
                        "plntloc": null,
                        "Quality": tagSplit[3] ?? ""

                      })

                    }

                  }
                } catch (e) {
                  console.log('Error:', e.stack);
                }
              }
            }
          }
        }
        //Send Respone -- to user 
        //console.log(tagwisedata)
        res.send(JSON.stringify(tagwisedata))
      })
    })
  });

});




var port = process.env.PORT;
app.listen(port);
console.log('Ecscada API is runnning at ' + port);



