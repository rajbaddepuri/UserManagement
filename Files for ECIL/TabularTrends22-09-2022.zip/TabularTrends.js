import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import ReactHTMLTableToExcel from 'react-html-table-to-excel';
import Moment from 'moment';
import DateTimePicker from 'react-datetime-picker';

class TabularTrends extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            name: [],
            groupsSelectTagValues: [],
            selectedGroupName: [],
            StartDate: null,
            EndDate: null,
            startdateError: "",
            EnddateError: "",
            GroupnameError: "",
            selectedGroup:[]
        }

    }

    componentDidMount () {
        axios.get(process.env.REACT_APP_IP + 'api/GroupName?GroupName=').then((res) => {
            var temp = []
            console.log(res);
            res.data.map((data) => {
                temp.push(data.CURTRENDTITLE);
            });
            this.setState({ groupsSelectTagValues: temp }, () => {
                console.log(this.state.groupsSelectTagValues[0]);
            })
            //alert("ok")
            axios.get(process.env.REACT_APP_IP + 'api/GroupwithTrendsTimestamp?GroupName=' + this.state.groupsSelectTagValues[0]).
                then((res) => {
                    this.setState({
                        name: res.data
                    }, () => {
                        console.log(this.state.name)
                    });
                });
        });

    }

    groupSelected = e => {
        console.log("DropdoWNclicked");
        var value = e.target.value;
        console.log(value)

        this.setState({
            selectedGroup: value
        },()=>{
            console.log(this.state.selectedGroup)
        })
        // axios.get(process.env.REACT_APP_IP + 'api/GroupwithTrendsTimestamp?GroupName=' + value).then((res) => {
        //     this.setState({
        //         name: res.data
        //     })
        // })
    };

    handleChange_StartDate = date => {
        console.log("currantdate",date)
        this.setState({
            StartDate: date
        },()=>{
            console.log(this.state.StartDate)
        });
    }

    handleChange1_EndDate = date => {
        this.setState({
            EndDate: date
        },()=>{
            console.log(this.state.EndDate)
        });
    }
    //........validation handling...........
 handleVAlidations () {
    let validGropuname = false;
    let validStartdate = false;
    let validEnddate = false;
    let validDate = false;
    let validDateRange = false;



    ///..... group name.....///
     console.log(this.state.selectedGroup)
     if (this.state.selectedGroup == "") {
        console.log("........entred........")
        validGropuname = true
    }
    ///.......start date...///
     console.log(this.state.StartDate)
     if (this.state.StartDate == null) {
        console.log("........entred........")
        validStartdate = true
    }
    ///.......end date...///
     if (this.state.EndDate == null) {
        console.log("........entred........")
        validEnddate = true

    }
    //........end date should be greaterthen than start date.........////

     if (this.state.StartDate < this.state.EndDate) {

        validDate = true
    }

    ///........ the diffarance beteween the end date and startdate should be Les than 90 days......./////
     if (this.state.StartDate && this.state.EndDate !== null) {
        console.log("enterd")
        // To set two dates to two variables
         var date1 = new Date(this.state.StartDate);
         var date2 = new Date(this.state.EndDate);

        // To calculate the time difference of two dates
        var Difference_In_Time = date2.getTime() - date1.getTime();

        // To calculate the no. of days between two dates
        var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
        console.log(Difference_In_Days)
        if (Difference_In_Days >= 91) {
            validDateRange = true
        }
    }
    return { validGropuname, validStartdate, validEnddate, validDate, validDateRange };
}


//////------calling the historic  dataafter validation-----------------//////////
    
    historicData () {
       console.log("jasdgdhsgdasjdsaghdsahgadhs")
       console.log(this.selectedGroup)
       console.log(this.StartDate)
       console.log(this.state.EndDate)
        if (this.state.selectedGroup !== "") {
            this.state.state({
            startdateError: ""
        })
    }   
   
        if (this.state.StartDate !== null) {
       
            this.state.state({
            startdateError:"" 
        })
    }
        if (this.state.EndDate !== null) {
       
            this.state.state({
            startdateError: ""
        })
    }
    ///.............CALLING METHOD VALIDATION.....................///////////////////
    var { validGropuname, validStartdate, validEnddate, validDate, validDateRange } = this.handleVAlidations();
   
    if (validStartdate) {
        // alert("Please Select The Start Date")
       
        this.state.state({
            startdateError: " * Please Select The Start Date"
        })
    }
    if (validEnddate) {
        //alert("Please Select The End Date")
      
        this.state.state({
            startdateError: "* Please Select The End Date"
        })
    }
    if (validDate) {
        alert("The start date should not be greater than end date")
    }
    if (validDateRange) {
        alert("The start and end date should not be greater than 90 days")
    }
        var startdate = Moment(this.state.StartDate).format('YYYY-MM-DDTHH:mm:ss')
        var enddate = Moment(this.state.EndDate).format('YYYY-MM-DDTHH:mm:ss')
    console.log(startdate)
    console.log(enddate)
    //console.log(selectedGroup)
    //   //var api = "http://'+IP+'/ScadaClient/api/FileRead?PointName=DAS_GRP2&FromDt=2021-08-31T12:51:50&ToDt=2021-08-31T12:51:50";
        var api = process.env.REACT_APP_IP + "api/FileRead?PointName=" + this.state.selectedGroup + "&FromDt=" + startdate + "&ToDt=" + enddate;
      
    //  //var api ="https://localhost:44348/api/FileRead?PointName=DAS_GRP2&FromDt=2022-01-29T10:00:50&ToDt=2022-01-29T18:51:50"
    //   //var api ="http://localhost/ScadaClient/api/FileRead?PointName=DAS_GRP2&FromDt=2022-02-09T10:00:50&ToDt=2022-02-09T18:51:50"
    //   var api = "http://localhost:8060/historicdata"
    // console.log(api)
        if (!validGropuname && !validStartdate && !validEnddate && !validDate && !validDateRange) {
            console.log(api)
            axios({
                method: 'post',
                url: process.env.REACT_APP_NODE_IP + "historicdata",
                headers: {},
                data: {
                    "fromDate": startdate, "toDate": enddate, "selctedGroup": this.selectedGroup
                }
            }).then((res) => {
                console.log(res)
                var tagData = res.data;
                console.log(tagData)
                if (tagData.length == 0) {
                    alert("There is no data Present in Selected dates")
                    window.location.reload();
                }
            })
        
    }

}
    //axios.get(api).then(res => {
    
    render () {
        return (
            <body className="font-montserrat">
                    <div id="main_content">
                            <div class="section-body">
                                <div class="container-fluid">
                                    <div class="row clearfix">
                                        <div class="col-lg-12">
                                            <div class="d-lg-flex justify-content-between">
                                                <ul class="nav nav-tabs page-header-tab">
                                                    <li class="nav-item"><Link to="/AreaTrends" class="nav-link " data-toggle="tab" href="">Trends</Link></li>

                                                    <li class="nav-item"><Link to="/HistTrends" class="nav-link " data-toggle="tab" href="">Historic Trends</Link></li>

                                                    <li class="nav-item"><Link to="/TabularTrends" class="nav-link active show" data-toggle="tab" href="#Change_Password">Tabular Trends </Link></li>
                                                    <li class="nav-item"><a href='/AdminDashboard'  >AdminDashboard</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                    </div>
                    
                            
                    <div class="section-body">
                        <div class="container-fluid" >
                            <div class="row">
                                {/* Select Group DropDown-------------------------------------- */}
                                <div class="col-md-2" style={{ textAlign: "left" }}>

                                    <div class="row" >
                                        <div class="col-md-6" style={{ textAlign: "right" }}>
                                            <label>Select Group: </label>
                                        </div>
                                        <div class="col-md-6" style={{ textAlign: "right" }}>
                                            <select className="custom-select" value={this.state.selectedGroupName} style={{ width: "130px" }} onChange={this.groupSelected} >


                                                {this.state.groupsSelectTagValues.map(name => (
                                                    < option value={name}>{name}</option>
                                                ))}

                                            </select>
                                            <span style={{ fontWeight: "", color: "red" }}>{this.state.GroupnameError}</span>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-2" style={{ textAlign: "left" }}>
                                    <div class="row" >
                                        <div class="col-md-6" style={{ textAlign: "right" }}>
                                            <label>Start Date: </label>
                                        </div>
                                        <div class="col-md-6" style={{ textAlign: "right" }}>

                                            <DateTimePicker type="datetime-local" name="StartDate"
                                                value={this.state.StartDate} placeholderText="StartDate" disableClock={false} maxDate={new Date()} clearAriaLabel="Clear value"
                                                onChange={this.handleChange_StartDate}
                                            />
                                            <span style={{ fontWeight: "", color: "red" }}>{this.state.startdateError}</span>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-md-2" style={{ textAlign: "left" }}>
                                    <div class="row" style={{ marginLeft: "120px" }}>
                                        <div class="col-md-6" style={{ textAlign: "right" }}>
                                            <label>End Date: </label>
                                        </div>
                                        <div class="col-md-6" style={{ textAlign: "right" }}>
                                            <DateTimePicker type="datetime-local" name="EndDate" placeholderText="End Date" disableClock={false} maxDate={new Date()} clearAriaLabel="Clear value"
                                                value={this.state.EndDate} onChange={this.handleChange1_EndDate}
                                               
                                            />
                                            <span style={{ fontWeight: "", color: "red" }}>{this.state.EnddateError}</span>   </div>
                                    </div>
                                </div>

                                <div class="row" style={{ marginLeft: "260px" }} >
                                    <div class="col-md-6" style={{ textAlign: "right" }}>

                                        <button className="btn btn-primary"   type="submit" style={{ marginTop: "0px", color: "white", height: "35px", backgroundColor: "rgb(51, 122, 183)" }} onClick={this.historicData} >Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                            
                                <div className="tab-content">
                                    <div className="tab-pane fade show active" id="list" role="tabpanel">
                                        <div className="row clearfix">
                                            <div className="col-lg-12">
                                                <div className="table-responsive" id="users">
                                                    <div>
                                                        <ReactHTMLTableToExcel
                                                            className="btn btn-info"
                                                            table="emp"
                                                            filename="ReportExcel"
                                                            sheet="Sheet"
                                                            buttonText="Export excel" />
                                                    </div>
                                                    <table className="table  table-vcenter  table_custom border-style list">
                                                        <table id="emp" className="table" >
                                                            <thead style={{ textAlign: "left", backgroundColor: "yellow" }}>
                                                            <tr>
                                                                <th style={{ textTransform: "none", color: "black", fontWeight: 'bold' }}>Time stamp</th>
                                                                    <th style={{ textTransform: "none", color: "black", fontWeight: 'bold' }}>Tag Name</th>
                                                                    {/* <th style={{ textTransform: "none", color: "white" , fontWeight: 'bold'}}>Upper Value</th>
                                                                    <th style={{ textTransform: "none", color: "white", fontWeight: 'bold' }}>Lower Value</th> */}
                                                                    <th style={{ textTransform: "none", color: "black", fontWeight: 'bold' }}>Current Value</th>
                                                                    
                                                                    {/*    <th>Tag 3</th>
												<th>Tag 4</th>
												<th>Tag 5</th>
												<th>Tag 6</th>
												<th>Tag 7</th> */}
                                                                </tr>
                                                            </thead>
                                                            <tbody>

                                                                {this.state.name == null ? "" : this.state.name.map((name) => {


                                                                    return <tr className="" style={{ textAlign: "left", backgroundColor: "white", borderWidth: "1px", borderColor: "#FFFFFF", borderStyle: "solid" }}>

                                                                        {/* Date */}
                                                                        <td className="hidden-xs" >{name.timestamp}</td>

                                                                        {/* Time */}
                                                                        <td> {name.pointname}</td>

                                                                        {/* DeviceName */}
                                                                        {/* <td  >{name.UPPERVALUE} </td> */}

                                                                        {/* TagName */}
                                                                        {/* <td className="hidden-xs" >{name.LOWERVALUE}</td> */}
                                                                        <td className="hidden-xs" >{name.fvalue}</td>

                                                                        {/* Description */}


                                                                    </tr>
                                                                })}

                                                            </tbody>
                                                        </table>
                                                    </table>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                

                        

                    </div>
            </body>
        )
    }
}
export default TabularTrends;