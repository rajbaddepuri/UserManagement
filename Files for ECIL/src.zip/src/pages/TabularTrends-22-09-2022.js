import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import IP from './Utiltys';
import ReactHTMLTableToExcel from 'react-html-table-to-excel';

class TabularTrends extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            name: [],
            groupsSelectTagValues:[],
            selectedGroupName:[]

        }
    }

    componentDidMount() {
        
        axios.get('http://'+IP+'/ScadaClient/api/GroupName?GroupName=').
        then((res) => {
            var temp = []
            console.log(res)
            res.data.map((data)=>{
                temp.push(data.CURTRENDTITLE)
             })
             this.setState({ groupsSelectTagValues: temp},()=>{
                console.log(this.state.groupsSelectTagValues[0])
            })
            //alert("ok")
            //http://192.168.0.45/ScadaClient/api/FileRead?PointName=DAS_GRP2&FromDt=2022-07-30T12:00:00&ToDt=2022-08-04T12:00:00
           //axios.get('http://'+IP+'/ScadaClient/api/GroupwithTrendsTimestamp?GroupName=' + this.state.groupsSelectTagValues[0]).
           // npm install --save react-html-table-to-excel --legacy-peer-deps
            axios.get("http://192.168.0.45/Scadaclient/api/FileRead?PointName=DAS_GRP2&FromDt=2022-07-30T12:00:00&ToDt=2022-07-31T12:00:00").
            then((res) => {
            this.setState({
                name:res.data
            },()=>{
                console.log(this.state.name)
            })
        }) 
        })

        }

     groupSelected = e =>{
        console.log("DropdoWNclicked");
        var value = e.target.value;
          console.log(value)
      
        this.setState({
            selectedGroupName : value
        })
        axios.get('http://'+IP+'/ScadaClient/api/GroupwithTrendsTimestamp?GroupName=' + value).
        then((res) => {
        this.setState({
            name:res.data
        })
            
        })
      
    
      };
    render() {
        return (
            <body className="font-montserrat">
                <div>


                    <div id="main_content">

                        <div >

                            <div class="section-body">
                                <div class="container-fluid">
                                    <div class="row clearfix">
                                        <div class="col-lg-12">
                                            <div class="d-lg-flex justify-content-between">
                                                <ul class="nav nav-tabs page-header-tab">
                                                    <li class="nav-item"><Link to="/AreaTrends" class="nav-link " data-toggle="tab" href="">Trends</Link></li>

                                                    <li class="nav-item"><Link to="/HistTrends" class="nav-link " data-toggle="tab" href="">Historic Trends</Link></li>

                                                    <li class="nav-item"><Link to="/TabularTrends" class="nav-link active show" data-toggle="tab" href="#Change_Password">Tabular Trends </Link></li>
                                                    <li class="nav-item"><a href='/AdminDashboard'  >AdminDashboard</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>



                            <div className="section-body">

                                <div className="row clearfix">
                                    <div className="col-xl-12 col-lg-12">
                                        <div className="card">
                                            <div className="card-header">
                                                <h3 className="card-title">Tabular Trends</h3>
                                                <div className="card-options">
                                                 {/* Select Group DropDown-------------------------------------- */}
                  


  <div class="col-md-6" style={{ textAlign: "right"}}>
    <label>Select Group: </label>
    </div>
    <div class="col-md-6" style={{ textAlign: "right" }}>
    <select className="custom-select" value={this.state.selectedGroupName} style={{width:"130px"}}  onChange={this.groupSelected} >
        

      {this.state.groupsSelectTagValues.map(name => (
        < option value={name}>{name}</option>
      ))}

    </select>
  </div>

                                                </div>
                                            </div>

                                        </div>
                                    </div>


                                </div>
                            </div>
                            <div className="">
                                <div className="tab-content">
                                    <div className="tab-pane fade show active" id="list" role="tabpanel">
                                        <div className="row clearfix">
                                            <div className="col-lg-12">
                                                <div className="table-responsive" id="users">
                                                <ReactHTMLTableToExcel
                    id="test-table-xls-button"
                    className="download-table-xls-button"
                    table="table-to-xls"
                    filename="tablexls"
                    sheet="tablexls"
                    buttonText="Download as XLS"/>
                                                    <table className="table  table-vcenter  table_custom border-style list">
                                                        <table className="table" id="table-to-xls">
                                                            <thead style={{ textAlign: "left", backgroundColor: "white" }}>
                                                                <tr>
                                                                <th style={{ textTransform: "none", color: "black", fontWeight: 'bold' }}>Time stamp</th>
                                                                    <th style={{ textTransform: "none", color: "black", fontWeight: 'bold' }}>Tag Name</th>
                                                                    {/* <th style={{ textTransform: "none", color: "white" , fontWeight: 'bold'}}>Upper Value</th>
                                                                    <th style={{ textTransform: "none", color: "white", fontWeight: 'bold' }}>Lower Value</th> */}
                                                                    <th style={{ textTransform: "none", color: "black", fontWeight: 'bold' }}>Current Value</th>
                                                                    
                                                                    {/*    <th>Tag 3</th>
												<th>Tag 4</th>
												<th>Tag 5</th>
												<th>Tag 6</th>
												<th>Tag 7</th> */}
                                                                </tr>
                                                            </thead>
                                                            <tbody>

                                                                {this.state.name == null ? "" : this.state.name.map((name) => {


                                                                    return <tr className="" style={{ textAlign: "left", backgroundColor: "white", borderWidth: "1px", borderColor: "#FFFFFF", borderStyle: "solid" }}>

                                                                        {/* Date */}
                                                                        <td className="hidden-xs" >{name.timestamp}</td>

                                                                        {/* Time */}
                                                                        <td> {name.pointname}</td>

                                                                        {/* DeviceName */}
                                                                        {/* <td  >{name.UPPERVALUE} </td> */}

                                                                        {/* TagName */}
                                                                        {/* <td className="hidden-xs" >{name.LOWERVALUE}</td> */}
                                                                        <td className="hidden-xs" >{name.fvalue}</td>

                                                                        {/* Description */}
                                                                        

                                                                      

                                                                    </tr>
                                                                })}

                                                            </tbody>
                                                        </table>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </body>
        )
    }
}
export default TabularTrends;