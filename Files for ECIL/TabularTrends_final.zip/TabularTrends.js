import { useState } from "react";
import axios from "axios";
import React from "react";
import "reactjs-popup/dist/index.css";
import { Link } from 'react-router-dom';
import DateTimePicker from 'react-datetime-picker';
import Moment from 'moment';
import ReactHTMLTableToExcel from 'react-html-table-to-excel';


const TabularTrends = () => {
    var selectedGroupName = "";

    

    //Data to be taken when Clicking Edit Button
    const [selectedTagData, SetSelectedTagData] = React.useState({
        tagName: "",
        axisIndex: 0,
        color: "",
        upperValue: "",
        lowerValue: "",
    });

    //Data to be taken when Clicking Edit Button
    const [tempselectedTagData, SetTempSelectedTagData] = React.useState({
        color: "",
        upperValue: "",
        lowerValue: "",
    });

   
    //DropDown Groups-----------------
    const [groupsSelectTagValues, setGroupsSelectTagValues] = React.useState([]);

    //isGroupSelected
    const [isGroupSelected, setIsGroupSelected] = React.useState(false);

    //SelectedGroup
    const [selectedGroup, setSelectedGroup] = React.useState("");

    //GroupTagsData---
    const [selectedGoupTagsData, setSelectedGoupTagsData] = React.useState([]);
    const [StartDate, setStartDate] = useState(null);
    const [EndDate, setEndDate] = useState(null);
    const [GroupnameError, setGroupnameError] = useState("");
    const [startdateError, setstartdateError] = useState("");
    const [EnddateError, setEnddateError] = useState("");

    //UseState for ChartSeries Data
    const [dataList, setDataList] = React.useState([{}]);

    //UseState for ChartOPtions Data
    const [histDataList, setHistDataList] = React.useState([]);
    //UseEffect
    React.useEffect(() => {
        if (!isGroupSelected) {
            getGroupNames();
        }
    }, []);
    //GetGroupNames Api Call------------------------------------------------------
    function getGroupNames () {
        console.log("Calling Groups Names Api")
        axios.get(process.env.REACT_APP_IP + 'api/GroupName?GroupName=').then(res => {
            var groupNamesData = res.data;
            console.log(groupNamesData)
            //Making 0 Index CURTRENDTITLE Default group --- toFetch values when page is rendering
            console.log("Default Group" + groupNamesData[0].CURTRENDTITLE)
            console.log(groupNamesData[0].CURTRENDTITLE)
            selectedGroupName = groupNamesData[0].CURTRENDTITLE;
            setSelectedGroup(groupNamesData[0].CURTRENDTITLE);
            //Setting GroupSelectTagValues---to  get Groups in DropDown
            var dropDownData = [];
            groupNamesData.map((tag) => {
                dropDownData.push({ value: tag.CURTRENDTITLE, label: tag.CURTRENDTITLE })
            })
            setGroupsSelectTagValues(dropDownData);
            setIsGroupSelected(true);
            //Fetching 0th Group Tag Data after Setting  Default group
            // fetchTagData();

        });
    }


    function fetchTagData () {
        console.log("Fetching Group Tag Values ---")
        console.log(selectedGroupName)
        console.log(selectedGroup)
        //http://'+IP+'/ScadaClient/api/GroupwithTrendsTimestamp?GroupName=DAS_GRP2
        if (selectedGroup != undefined) {
            var call = process.env.REACT_APP_IP + 'api/GroupwithTrendsTimestamp?GroupName=' + selectedGroupName;

            console.log(call)
            axios.get(call).then(res => {

                var tagData = [];

                tagData = res.data;
                console.log("Actual List")
                console.log(tagData)
                setSelectedGoupTagsData(tagData);


            })
        }
    }

    //........validation handling...........
    function handleVAlidations () {
        let validGropuname = false;
        let validStartdate = false;
        let validEnddate = false;
        let validDate = false;
        let validDateRange = false;
        ///..... group name.....///
        console.log(selectedGroup)
        if (selectedGroup == "") {
            console.log("........entred........")
            validGropuname = true
        }
        ///.......start date...///
        console.log(StartDate)
        if (StartDate == null) {
            console.log("........entred........")
            validStartdate = true
        }
        ///.......end date...///
        if (EndDate == null) {
            console.log("........entred........")
            validEnddate = true

        }
        //........end date should be less than start date.........////

        if (StartDate > EndDate) {

            validDate = true
        }

        ///........ the diffarance beteween the end date and startdate should be Les than 90 days......./////
        if (StartDate && StartDate !== null) {
            console.log("enterd")
            // To set two dates to two variables
            var date1 = new Date(StartDate);
            var date2 = new Date(StartDate);

            // To calculate the time difference of two dates
            var Difference_In_Time = date2.getTime() - date1.getTime();

            // To calculate the no. of days between two dates
            var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
            console.log(Difference_In_Days)
            if (Difference_In_Days >= 91) {
                validDateRange = true
            }
        }
        return { validGropuname, validStartdate, validEnddate, validDate, validDateRange };
    }



    function Historic () {
        console.log(selectedGroup)

        if (selectedGroup !== "") {
            setGroupnameError("")
        }
        if (StartDate !== null) {
            setstartdateError("")
        }
        if (EndDate !== null) {
            setEnddateError("")
        }
        ///.............CALLING METHOD VALIDATION.....................///////////////////
        var { validGropuname, validStartdate, validEnddate, validDate, validDateRange } = handleVAlidations();
        if (validGropuname) {
            //alert("Please Select Group Name")
            setGroupnameError(" * Please Select Group Name")
        }
        if (validStartdate) {
            // alert("Please Select The Start Date")
            setstartdateError(" * Please Select The Start Date")
        }
        if (validEnddate) {
            //alert("Please Select The End Date")
            setEnddateError("* Please Select The End Date")
        }
        if (validDate) {
            alert("The start date should not be greater than end date")
        }
        if (validDateRange) {
            alert("The start and end date should not be greater than 90 days")
        }
        var startdate = Moment(StartDate).format('YYYY-MM-DDTHH:mm:ss')
        var enddate = Moment(EndDate).format('YYYY-MM-DDTHH:mm:ss')
        console.log(startdate)
        console.log(enddate)
        console.log(selectedGroup)
        //   //var api = "http://'+IP+'/ScadaClient/api/FileRead?PointName=DAS_GRP2&FromDt=2021-08-31T12:51:50&ToDt=2021-08-31T12:51:50";
          var api = process.env.REACT_APP_IP+"api/FileRead?PointName="+selectedGroup+"&FromDt="+startdate+"&ToDt="+enddate;
        //  //var api ="https://localhost:44348/api/FileRead?PointName=DAS_GRP2&FromDt=2022-01-29T10:00:50&ToDt=2022-01-29T18:51:50"
        //   //var api ="http://localhost/ScadaClient/api/FileRead?PointName=DAS_GRP2&FromDt=2022-02-09T10:00:50&ToDt=2022-02-09T18:51:50"
        //   var api = "http://localhost:8060/historicdata"
        console.log(api)
        if (!validGropuname && !validStartdate && !validEnddate && !validDate && !validDateRange) {
            //axios.get(api).then(res => {
            //  var fromDate = response['fromDate'];
            //   var toDate =  response['toDate'];
            //   var selctedGroup = response['selctedGroup'];y
            axios({
                method: 'post',
                url: process.env.REACT_APP_NODE_IP + "historicdata",
                headers: {},
                data: {
                    "fromDate": startdate, "toDate": enddate, "selctedGroup": selectedGroup
                }
            }).then((res) => {
                console.log(res)
                var tagData = res.data;
                console.log(tagData)
                if (tagData.length == 0) {
                    alert("There is no data Present in Selected dates")
                    window.location.reload();
                }
                var series = [];
                var seriesData = [];
                selectedGoupTagsData.map((tag, i) => {
                    series.push([])
                    seriesData.push([])
                });
                var timeSeries = [];
                tagData.map((histTag, j) => {
                    if (selectedGoupTagsData[0].POINTNAME == histTag.pointname) {
                        // console.log(new Date(histTag.timestamp))
                        timeSeries.push(histTag.timestamp)
                    }
                });

                console.log(series)
                tagData.map((histTag, j) => {
                    selectedGoupTagsData.map((tag, i) => {
                        if (tag.POINTNAME == histTag.pointname) {

                            series[i].push(histTag)
                        }
                    })
                });

                setHistDataList(selectedGoupTagsData);
                //Setting DataList---------------------------------------
                var tempDataPoints = [];
                // console.log(tagData.length)
    
                setDataList(tempDataPoints);

            })
        }
    }





    //Select Group OnSelection Group
    const groupSelected = (e) => {
        console.log("DropdoWNclicked");
        var value = e.target.value;
        console.log(value)
        setSelectedGroup(value);
        selectedGroupName = value;
        fetchTagData();

    };


    return (
        <div >
            <div class="section-body">
                <div class="container-fluid">
                    <div class="row clearfix">
                        <div class="col-lg-12">
                            <div class="d-lg-flex justify-content-between">
                                <ul class="nav nav-tabs page-header-tab">
                                    <li class="nav-item"><Link to="/AreaTrends" class="nav-link " data-toggle="tab" href="">Trends</Link></li>

                                    <li class="nav-item"><Link to="/HistTrends" class="nav-link" data-toggle="tab" href="">Historic Trends</Link></li>

                                    <li class="nav-item"><Link to="/TabularTrends" class="nav-link active show" data-toggle="tab" href="#Change_Password">Tabular Trends </Link></li>
                                    <li class="nav-item"><a href='/AdminDashboard'  >AdminDashboard</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



            <div class="container-fluid" >
                <div class="row">
                    <div class="col-md-12">
                        <div class="card text-black bg-light mb-3">
                            {/* <div class="card-header">Graph</div> */}
                            <div class="card-body">
                                <div class="row">
                                    {/* Select Group DropDown-------------------------------------- */}
                                    <div class="col-md-2" style={{ textAlign: "left" }}>

                                        <div class="row" >
                                            <div class="col-md-6" style={{ textAlign: "right" }}>
                                                <label>Select Group: </label>
                                            </div>
                                            <div class="col-md-6" style={{ textAlign: "right" }}>
                                                <select className="custom-select" onChange={groupSelected} >
                                                    <option>Select Group</option>
                                                    {groupsSelectTagValues.map(name => (
                                                        <option value={name.value}>
                                                            {name.value}
                                                        </option>
                                                    ))}

                                                </select>
                                                <span style={{ fontWeight: "", color: "red" }}>{GroupnameError}</span>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="col-md-2" style={{ textAlign: "left" }}>
                                        <div class="row" >
                                            <div class="col-md-6" style={{ textAlign: "right" }}>
                                                <label>Start Date: </label>
                                            </div>
                                            <div class="col-md-6" style={{ textAlign: "right" }}>

                                                <DateTimePicker type="datetime-local" name="enddate" value={StartDate} onChange={setStartDate}
                                                    placeholderText="End Date" disableClock={false} maxDate={new Date()} clearAriaLabel="Clear value"

                                                />
                                                <span style={{ fontWeight: "", color: "red" }}>{startdateError}</span>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-2" style={{ textAlign: "left" }}>
                                        <div class="row" style={{ marginLeft: "120px" }}>
                                            <div class="col-md-6" style={{ textAlign: "right" }}>
                                                <label>End Date: </label>
                                            </div>
                                            <div class="col-md-6" style={{ textAlign: "right" }}>
                                                <DateTimePicker type="datetime-local" name="enddate"
                                                    value={EndDate} placeholderText="End Date" disableClock={false} maxDate={new Date()} clearAriaLabel="Clear value"
                                                    onChange={setEndDate}
                                                />
                                                <span style={{ fontWeight: "", color: "red" }}>{EnddateError}</span>   </div>
                                        </div>
                                    </div>

                                    <div class="row" style={{ marginLeft: "260px" }} >
                                        <div class="col-md-6" style={{ textAlign: "right" }}>

                                            <button className="btn btn-primary" style={{ marginTop: "0px", color: "white", height: "35px", backgroundColor: "rgb(51, 122, 183)" }} onClick={Historic} >Submit</button>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* //Table ----------------------------------------------------------------------------------------------------------- */}
                <div className="tab-content">
                    <div className="tab-pane fade show active" id="list" role="tabpanel">
                        <div className="row clearfix">
                            <div className="col-lg-12">
                                <div className="table-responsive" id="users">
                                    <div>
                                        <ReactHTMLTableToExcel
                                            className="btn btn-info"
                                            table="emp"
                                            filename="ReportExcel"
                                            sheet="Sheet"
                                            buttonText="Export excel" />
                                    </div>
                                    <br/>

                        <table class="table table-bordered" color="black" >
                            <th scope="col" style={{ fontWeight: "bold" }}>TimeStamp</th>
                            <th scope="col" style={{ fontWeight: "bold" }}>TagName</th>
                            <th scope="col" style={{ fontWeight: "bold" }}>FValue</th>
                            {
                                histDataList != undefined ? histDataList.map((tag, i) => {

                                    var list = dataList[i];
                                    return (
                                        <tr>
                                            <td style={{ color: list?.color }}>{tag.timeStampTime}</td>
                                            
                                            
                                            <td style={{ color: list?.color }}>
                                                {tag.POINTNAME}
                                            </td>
                                            {/* // <td style={{ color: list?.color }}>
                        {tag.Quality}
                      </td> */}
                                            <td style={{ color: list?.color }}>
                                                {tag.fvalue}
                                            </td>
                                           
                                        </tr>
                                    );
                                }) : <div></div>}
                        </table>
                    </div>
                </div>
                        </div>
                        </div>
                        </div>                  
                <div>
                </div>
            </div>
        </div>
    );
};

export default TabularTrends;
