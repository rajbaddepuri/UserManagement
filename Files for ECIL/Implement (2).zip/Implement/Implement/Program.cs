﻿using System;
using System.Runtime.InteropServices;
using System.Xml.Serialization;

namespace Implement
{
    public struct statusrec
    {
        #region structure declaration
        /*
        public static int dbirlow=1;
        public static int dblolo =1;
        public static int dblow = 1;
        public static int dbrocl = 1;
        public static int dbroch = 1;
        public static int dbhigh = 1;
        public static int dbhihi = 1;
        public static int dbirhigh = 1;
        public static int dbmsl = 1;
        public static int dbcnp = 1;
        public static int dbfailed = 1;
        public static int dbunack = 1;
        public static int dbbusied = 1;
        public static int dbalarminhibit = 1;
        public static int dbalarm = 1;
        public static int dbchattering1 = 1;
        public static int dbchattering2 = 1;
        public static int existing = 1;
        public static int dbold = 1;
        public static int dbontest = 1;
        public static int dbcommandedop = 1;
        
         
         
           public statusrec(int dbirlow, int dblolo, int dblow, int dbrocl, int dbroch, int dbhigh, int dbhihi, int dbirhigh,
            int dbmsl, int dbcnp, int dbfailed, int dbunack, int dbbusied, int dbalarminhibit, int dbalarm, int dbchattering1, int dbchattering2, int existing,
            int dbold, int dbontest, int dbcommandedop)
        {
              this.dbirlow = dbirlow;
            this.dblolo = dblolo;
            this.dblow = dblow;
            this.dbrocl = dbrocl;
            this.dbroch = dbroch;
            this.dbhigh = dbhigh;
            this.dbhihi = dbhihi;
            this.dbirhigh = dbirhigh;
            this.dbmsl = dbmsl;
            this.dbcnp = dbcnp;
            this.dbfailed = dbfailed;
            this.dbunack = dbunack;
            this.dbbusied = dbbusied;
            this.dbalarminhibit = dbalarminhibit;
            this.dbalarm = dbalarm;
            this.dbchattering1 = dbchattering1;
            this.dbchattering2 = dbchattering2;
            this.existing = existing;
            this.dbold = dbold;
            this.dbontest = dbontest;
            this.dbcommandedop = dbcommandedop;
        }
        
         */
        #endregion
        #region structure declaration - setter methods
        public static UInt32 dbirlow = 1;// { get;  set; }
        public static UInt32 dblolo = 1;// { get;  set; }
        public static UInt32 dblow = 1;//{ get;  set; }
        public static UInt32 dbrocl = 1;//{ get;  set; }
        public static UInt32 dbroch = 1;//{ get;  set; }
        public static UInt32 dbhigh = 1;//{ get;  set; }
        public static UInt32 dbhihi = 1;//{ get;  set; }
        public static UInt32 dbirhigh = 1;//{ get;  set; }
        public static UInt32 dbmsl = 1;// { get;  set; }
        public static UInt32 dbcnp = 1;//{ get;  set; }
        public static UInt32 dbfailed = 1;//{ get;  set; }
        public static UInt32 dbunack = 1;//{ get;  set; }
        public static UInt32 dbbusied = 1;//{ get;  set; }
        public static UInt32 dbalarminhibit = 1;//{ get; private set; }
        public static UInt32 dbalarm = 1;//{ get;  set; }
        public static UInt32 dbchattering1 = 1;//{ get;  set; }
        public static UInt32 dbchattering2 = 1;//{ get;  set; }
        public static UInt32 existing = 1;// { get;  set; }
        public static UInt32 dbold = 1;//{ get;  set; }
        public static UInt32 dbontest = 1;//{ get;  set; }
        public static UInt32 dbcommandedop = 1;
        #endregion
        #region constructor

        public statusrec(UInt32 dbirlow, UInt32 dblolo, UInt32 dblow, UInt32 dbrocl, UInt32 dbroch, UInt32 dbhigh, UInt32 dbhihi, UInt32 dbirhigh,
            UInt32 dbmsl, UInt32 dbcnp, UInt32 dbfailed, UInt32 dbunack, UInt32 dbbusied, UInt32 dbalarminhibit, UInt32 dbalarm, UInt32 dbchattering1, UInt32 dbchattering2, UInt32 existing,
            UInt32 dbold, UInt32 dbontest, UInt32 dbcommandedop)
        {
            dbirlow = dbirlow;
            dblolo = dblolo;
            dblow = dblow;
            dbrocl = dbrocl;
            dbroch = dbroch;
            dbhigh = dbhigh;
            dbhihi = dbhihi;
            dbirhigh = dbirhigh;
            dbmsl = dbmsl;
            dbcnp = dbcnp;
            dbfailed = dbfailed;
            dbunack = dbunack;
            dbbusied = dbbusied;
            dbalarminhibit = dbalarminhibit;
            dbalarm = dbalarm;
            dbchattering1 = dbchattering1;
            dbchattering2 = dbchattering2;
            existing = existing;
            dbold = dbold;
            dbontest = dbontest;
            dbcommandedop = dbcommandedop;
        }

        #endregion
    }

    public struct dbcv
    {
        // public float fvalue;
        // public int ivalue;
        static statusrec srec;

        //public static float fvalue = 1;//{ get; set; }
        //public static int ivalue = 1;//{ get; set; }
        public dbcv(float fvalue, int ivalue, out statusrec statusrec)
        {
            //fvalue = fvalue; ivalue = ivalue;
            //fvalue = 1;
            //ivalue = 1;
            //statusrec st = new statusrec();
            statusrec statusrec1 = new statusrec(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);
        }
    }
    //STATUSREC







    public class Program
    {

        public struct statusrec
        {
            uint dbirlow;
            uint dblolo;
            uint dblow;
            uint dbrocl;
            uint dbroch;
            uint dbhigh;
            uint dbhihi;
            uint dbirhigh;
            uint dbmsl;
            uint dbcnp;
            uint dbfailed;
            uint dbunack;
            uint dbopentered;
            uint dbbusied;
            uint dbalarminhibit;
            uint dbalarm;
            uint dbchattering1;
            uint dbchattering2;
            uint existing;
            uint dbold;
            uint dbontest;
            uint dbcommandedop;
            private int v1;
            private int v2;
            private int v3;
            private int v4;
            private int v5;
            private int v6;
            private int v7;
            private int v8;
            private int v9;
            private int v10;
            private int v11;
            private int v12;
            private int v13;
            private int v14;
            private int v15;
            private int v16;
            private int v17;
            private int v18;
            private int v19;
            private int v20;
            private int v21;

            public statusrec(int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10, int v11, int v12, int v13, int v14, int v15, int v16, int v17, int v18, int v19, int v20, int v21) : this()
            {
                this.v1 = v1;
                this.v2 = v2;
                this.v3 = v3;
                this.v4 = v4;
                this.v5 = v5;
                this.v6 = v6;
                this.v7 = v7;
                this.v8 = v8;
                this.v9 = v9;
                this.v10 = v10;
                this.v11 = v11;
                this.v12 = v12;
                this.v13 = v13;
                this.v14 = v14;
                this.v15 = v15;
                this.v16 = v16;
                this.v17 = v17;
                this.v18 = v18;
                this.v19 = v19;
                this.v20 = v20;
                this.v21 = v21;
            }
        };

        public struct dbcv
        {
            float fvalue;
            int ivalue;
            statusrec srec;
            private int v1;
            private int v2;

            public dbcv(int v1, int v2, out statusrec statusrec1) : this()
            {
                this.v1 = v1;
                this.v2 = v2;
                statusrec1 = default;
            }
        };
        /*
        // DBCV;
        statusrec statusrec11 = new statusrec(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);
        //dbcv dbcv = new dbcv(1, 1, ref statusrec11);
        //dbcv dbcv = new dbcv();
        dbcv dbcv;
        public Program(dbcv dbcv)
        {
            this.dbcv = dbcv;
        }

        dbcv cvv1;
        */
        public Program() { }

        [DllImport("dbserver.dll", EntryPoint = "DbGetSCADACurValue", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
        public static extern int DbGetSCADACurValue(UInt32 tpointId, out dbcv dbcv, out UInt32 time, out UInt32 pointType, UInt32 x);  //[MarshalAs(UnmanagedType.LPStruct)] 
        [DllImport("dbserver.dll", EntryPoint = "DbGetSCADACurValueVC", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
        public static extern float DbGetSCADACurValueVC(UInt32 tpointId, int ival, float fval);  //[MarshalAs(UnmanagedType.LPStruct)] 

        [DllImport("dbserver.dll", EntryPoint = "DbClientVC", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
        public static extern int DbClientVC();



        [DllImport("dbserver.dll", EntryPoint = "DbClientWebServer", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
        public static extern int DbClientWebServer();



        [DllImport("dbserver.dll", EntryPoint = "dllink", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
        public static extern int dllink();
        [DllImport("dbserver.dll")]

        public static extern int howareyou();
        [DllImport("dbserver.dll")]

        public static extern long GetPDBSize();
        [DllImport("dbserver.dll", EntryPoint = "GetPDBSize", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

        public static extern int hello(int a);


        [DllImport("dbserver.dll", EntryPoint = "GetServerName", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
        public static extern string GetServerName();  //[MarshalAs(UnmanagedType.LPStruct)] 

        [DllImport("scriptingdll.dll", EntryPoint = "hallo1", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
        public static extern int hallo1();  //[MarshalAs(UnmanagedType.LPStruct)] 




        public static void Main()
        {

            //UInt32 time;

            //time= 1;

            uint pointType;
            int yy = 5;
            statusrec statusrec1 = new statusrec(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);
            dbcv cv = new dbcv(1, 1, out statusrec1);
            dbcv dvv = new dbcv();
            //, pointType;
            UInt32 tpointId;
            tpointId = 1;

            UInt32 time1 = 1;
            uint time;
            int ival = -1;
            float fval = -1;


            /*Console.WriteLine("output from dbserver dll of method howareyou: ");
            Console.WriteLine(howareyou());
            Console.WriteLine("output from dbserver dll of method hello: "); */
            //Console.WriteLine(hello(yy));
            //var dd =hallo1();
            //Console.WriteLine(dd);
            int dd = DbClientWebServer();
            int objDbClientVC = DbClientVC();
            int objdllink = dllink();
            if (dd < 0)
            {
                Console.WriteLine("SCADA mappling error");
            }
            else
            {
                var aa = DbGetSCADACurValueVC(1, 0,0);
            }
            //Console.WriteLine(a);
            //var ptr = GetPDBSize();
            // var ptrDbClient = DbGetSCADACurValue();


            // int aa;

            //aa = DbGetSCADACurValueVC(tpointId, ival, fval);
            //Console.WriteLine(ptrDbClient);
            //Console.WriteLine(ptrDbClient);
            //Console.WriteLine(DbGetSCADACurValue(tpointId,ref cv, out &time, out &pointType, 3000)); 
        }

    }
}
