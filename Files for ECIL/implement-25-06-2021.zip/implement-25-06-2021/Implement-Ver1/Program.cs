﻿using System;
using System.Runtime.InteropServices;
namespace Implement
{
    class Program
    {
        [DllImport("attemptDll.dll")]
        public static extern IntPtr Create(int x);
        [DllImport("attemptDll.dll")]
        public static extern int AttemptAdd(IntPtr t, int x);
        static void Main(string[] args)
        {
            IntPtr tst = Create(6);
            Console.WriteLine(AttemptAdd(tst, 10));
            Console.WriteLine("Hello World!");
        }
    }
}
