
#pragma once
class Attempt {
	int x;
public: Attempt(int x);
	int adding(int y);
};

extern "C" __declspec(dllexport) void* Create(int x) {
	/*std::cout << "HERE" << std::endl;
	return (void*) new Testing(x);*/
	return (void*) new Attempt(x);
}
extern "C" __declspec(dllexport) int AttemptAdd(Attempt * a, int y) {
	return a->adding(y);
}