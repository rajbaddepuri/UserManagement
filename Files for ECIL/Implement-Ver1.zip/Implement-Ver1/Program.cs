﻿using System;
using System.Runtime.InteropServices;
using NHibernate.Mapping;

namespace Implement
{
    class Program  
    { 
        [DllImport("dbserver.dll")]  
        static public extern char DbClient();

        static void Main(string[] args)
        {
                  
            Console.WriteLine("Hello World!");

            if (DbClient()!=0)
            { 
                Console.WriteLine("ok");
            }
            else
                Console.WriteLine("DBclientcalled successful!");

        }
    }
}
