﻿using System;
using System.Runtime.InteropServices;
namespace Implement
{
    class Program
    {
        [DllImport("attemptDll.dll")]
        public static extern IntPtr Create(int x);
        [DllImport("attemptDll.dll")]
        public static extern int AttemptAdd(IntPtr t, int x);
        [DllImport("attemptDll.dll")]
        public static extern int Multiply(IntPtr x, int y, int z);

        [DllImport("attemptDll.dll")]
        public static extern int Mul(int x, int y, int z);


        [DllImport("attemptDll.dll")]
        public static extern int Add(int a, int b);
        static void Main(string[] args)
        {
            IntPtr s = Create(6);
           Console.WriteLine(AttemptAdd(s, 10));
            Console.WriteLine(Multiply(s, 2,3));           
            Console.WriteLine("Hello World!");
        }
    }
}
