#include "pch.h"
#include "attempt.h"

Attempt::Attempt() {
}
Attempt::Attempt(int x) {
	this->x = x;
}
int Attempt::adding(int y) {
	return this->x + y;
}
int Attempt::Multiply(int y, int z)
{
	return this->x * y * z;
}
int Attempt::Mul(int a, int y, int z) {
	return a * y * z;
}
int Attempt::Add(int a, int b) {
	//a = this->a;
	//b = this->b;
	return a + b;
}