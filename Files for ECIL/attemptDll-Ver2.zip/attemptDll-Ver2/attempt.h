
#pragma once
class Attempt {
	int x;
	int a, b;
public:
	  Attempt();
	  Attempt(int x);
	int adding(int y);
	int Add(int a, int b);
	int Multiply(int y, int z);
	int Mul(int x, int y, int z);
}; 

extern "C" __declspec(dllexport) void* Create(int x) {
	/*std::cout << "HERE" << std::endl;
	return (void*) new Testing(x);*/
	return (void*) new Attempt(x);
}
extern "C" __declspec(dllexport) int AttemptAdd(Attempt * a, int y) {
	return a->adding(y);
}
extern "C" __declspec(dllexport) int __stdcall Multiply(Attempt *x, int y, int z) {
	return x->Multiply(y, z);
}
extern "C" __declspec(dllexport) int __stdcall Mul(int x, int y, int z) {
	return Mul(x, y, z);
}

extern "C" {
	__declspec(dllexport) int __stdcall Add(int a, int b)
	{		
	return  Add(a, b);
	}
}
 