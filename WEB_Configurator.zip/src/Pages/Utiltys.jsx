  var IP = "localhost"
export default IP ;