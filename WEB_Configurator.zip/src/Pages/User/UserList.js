import React from 'react';
import { Table, Button, Alert } from 'react-bootstrap';
import {Link} from 'react-router-dom';
import axios from 'axios';


class UserList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      users: [],
      response: {}
    }
  }

  componentDidMount() {
    const apiUrl = process.env.REACT_APP_IP+'api/userdetail?userid=0';

    fetch(apiUrl)
      .then(res => res.json())
      .then(
        (result) => {
          this.setState({
            users: result
          });
          console.log(this.state.users)
        },
        (error) => {
          this.setState({ error });
        }
      )
  }

  deleteProduct(UserID) {
    console.log(UserID)
    var url = process.env.REACT_APP_NODE_DELETE_USER_API_URL;
    var UserIdEndpoint = url + "User_Id=" + UserID;
    
    axios.get(UserIdEndpoint, {
    }).then((response) => {
      // //////console.log(response)
     var data = response.data;
      alert(data);
      window.location.reload();
    
    }).catch(error => {
      //console.log(data.length);
     // console.log(error.response)
     
    });
   
  }

    convert = dateRange =>
  dateRange
    .split(" - ")
    .map(date => new Intl.DateTimeFormat("en-US").format(new Date(date)));

     

  render() {
    const { error, users} = this.state;

    if(error) {
      return (
        <div>Error: {error.message}</div>
      )
    } else {
      return(
        <div className="page">

          
        <div className="section-body">
          
         
          <ul class="nav nav-tabs page-header-tab">
          {sessionStorage.getItem("Admin")?
          <li class="nav-item"><Link to="/addUser" class="nav-link inactive show">Add User</Link></li>
          :""
                  }
          <li class="nav-item"><Link to="/viewUser" class="nav-link active show" >View User</Link></li>
      </ul>
   
    
      </div>
        {/* <h2>User List</h2>*/} <Table> 
          <table className="table table-hover table-vcenter text-nowrap table_custom border-style list"> 
          <table className="table table-hover ">
                                    
            <thead style={{textAlign:"-webkit-center", backgroundColor:"#252d42"}}>
              <tr >
                <th style={{textTransform:"none", color:"#E5E5E5"}}>Employee Code</th>
                <th style={{textTransform:"none", color:"#E5E5E5"}}>First Name</th>
                <th style={{textTransform:"none", color:"#E5E5E5"}}>Last Name</th>
                <th style={{textTransform:"none", color:"#E5E5E5"}}>Phone Number</th>
                <th style={{textTransform:"none", color:"#E5E5E5"}}>Email ID</th>
                {/* <th style={{textTransform:"none", color:"#E5E5E5"}}>DOB</th> */}
                <th style={{textTransform:"none", color:"#E5E5E5"}}>Gender</th>
                <th style={{textTransform:"none", color:"#E5E5E5"}}>Department</th>
                {/* <th style={{textTransform:"none", color:"#E5E5E5"}}>Action</th>
                    */}
                 {sessionStorage.getItem("Admin")?
                <th style={{textTransform:"none", color:"#E5E5E5"}}>Edit</th>                
                  :""   
                                           
                }  
                 {sessionStorage.getItem("Admin")?
                <th style={{textTransform:"none", color:"#E5E5E5"}}>Delete</th>                
                  :""   
                                           
                }                               
                                            
                                        
              </tr>
            </thead>
            <tbody>
              {this.state.users.map(data => (
                <tr key={data.UserID}>
                  <td>{data.EmpCode}</td>
                  <td style={{color:"black"}}>{data.FirstName}</td>
                  <td style={{color:"black"}}>{data.LastName}</td>
                  <td style={{color:"black"}}>{data.Mobile}</td>
                  <td style={{color:"black"}}>{data.EmailID}</td>
                  {/* <td style={{color:"black"}}>{this.convert(data.DOB)}</td> */}
                  <td style={{color:"black"}}>{data.Gender}</td>
                  <td style={{color:"black"}}>{data.Department}</td>
                  
                
                  {sessionStorage.getItem("Admin")?
                  <td>
                    <Button variant="info" onClick={() => this.props.editProduct(data.UserID)}>Edit</Button>
                      </td>
                       :""  
                   }
                    {sessionStorage.getItem("Admin")?
                  <td>
                    <Button variant="info" onClick={() => this.deleteProduct(data.UserID)}>Delete</Button>
                      </td>
                    
                
                       :""
                       
                   }
                </tr>
              ))}
            </tbody>
            </table>
            </table>
          </Table>
        </div>
      )
    }
  }
}

export default UserList;